﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CreatePostForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CreatePostForm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Close = New System.Windows.Forms.Button()
        Me.menu = New System.Windows.Forms.PictureBox()
        Me.SidebarTransitionTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.delete = New System.Windows.Forms.Button()
        Me.deletedata = New System.Windows.Forms.DataGridView()
        Me.post_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.post = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pbPreview = New System.Windows.Forms.PictureBox()
        Me.TBoxContent = New System.Windows.Forms.TextBox()
        Me.BtnSendMessage = New System.Windows.Forms.Button()
        Me.BtnClear = New System.Windows.Forms.Button()
        Me.BtnAttachFile = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.sidebar = New System.Windows.Forms.Panel()
        Me.report_btn = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.BtnHomePage = New System.Windows.Forms.Button()
        Me.BtnLogout = New System.Windows.Forms.Button()
        Me.BtnManageRequest = New System.Windows.Forms.Button()
        Me.BtnCreatePost = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        CType(Me.menu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.deletedata, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbPreview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.sidebar.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Close)
        Me.Panel1.Controls.Add(Me.menu)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(956, 34)
        Me.Panel1.TabIndex = 3
        '
        'Close
        '
        Me.Close.FlatAppearance.BorderSize = 0
        Me.Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Close.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Close.ForeColor = System.Drawing.Color.Black
        Me.Close.Image = CType(resources.GetObject("Close.Image"), System.Drawing.Image)
        Me.Close.Location = New System.Drawing.Point(921, 8)
        Me.Close.Name = "Close"
        Me.Close.Size = New System.Drawing.Size(22, 17)
        Me.Close.TabIndex = 11
        Me.Close.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Close.UseVisualStyleBackColor = True
        '
        'menu
        '
        Me.menu.Image = CType(resources.GetObject("menu.Image"), System.Drawing.Image)
        Me.menu.Location = New System.Drawing.Point(12, 5)
        Me.menu.Name = "menu"
        Me.menu.Size = New System.Drawing.Size(45, 23)
        Me.menu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.menu.TabIndex = 1
        Me.menu.TabStop = False
        '
        'SidebarTransitionTimer
        '
        Me.SidebarTransitionTimer.Interval = 10
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.delete)
        Me.Panel3.Controls.Add(Me.deletedata)
        Me.Panel3.Controls.Add(Me.pbPreview)
        Me.Panel3.Controls.Add(Me.TBoxContent)
        Me.Panel3.Controls.Add(Me.BtnSendMessage)
        Me.Panel3.Controls.Add(Me.BtnClear)
        Me.Panel3.Controls.Add(Me.BtnAttachFile)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Location = New System.Drawing.Point(54, 34)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(902, 483)
        Me.Panel3.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(146, 98)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 18)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Delete Post"
        '
        'delete
        '
        Me.delete.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.delete.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.delete.ForeColor = System.Drawing.Color.White
        Me.delete.Location = New System.Drawing.Point(160, 418)
        Me.delete.Name = "delete"
        Me.delete.Size = New System.Drawing.Size(84, 35)
        Me.delete.TabIndex = 14
        Me.delete.Text = "Delete"
        Me.delete.UseVisualStyleBackColor = False
        '
        'deletedata
        '
        Me.deletedata.BackgroundColor = System.Drawing.Color.White
        Me.deletedata.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.deletedata.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.deletedata.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.deletedata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.deletedata.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.post_id, Me.post})
        Me.deletedata.Location = New System.Drawing.Point(35, 139)
        Me.deletedata.Name = "deletedata"
        Me.deletedata.Size = New System.Drawing.Size(344, 273)
        Me.deletedata.TabIndex = 13
        '
        'post_id
        '
        Me.post_id.DataPropertyName = "post_id"
        Me.post_id.HeaderText = "ID"
        Me.post_id.Name = "post_id"
        Me.post_id.Width = 50
        '
        'post
        '
        Me.post.DataPropertyName = "post"
        Me.post.HeaderText = "Post"
        Me.post.Name = "post"
        Me.post.Width = 250
        '
        'pbPreview
        '
        Me.pbPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbPreview.Location = New System.Drawing.Point(419, 165)
        Me.pbPreview.Name = "pbPreview"
        Me.pbPreview.Size = New System.Drawing.Size(427, 247)
        Me.pbPreview.TabIndex = 10
        Me.pbPreview.TabStop = False
        '
        'TBoxContent
        '
        Me.TBoxContent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TBoxContent.Location = New System.Drawing.Point(419, 72)
        Me.TBoxContent.Multiline = True
        Me.TBoxContent.Name = "TBoxContent"
        Me.TBoxContent.Size = New System.Drawing.Size(427, 66)
        Me.TBoxContent.TabIndex = 3
        '
        'BtnSendMessage
        '
        Me.BtnSendMessage.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.BtnSendMessage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSendMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSendMessage.ForeColor = System.Drawing.Color.White
        Me.BtnSendMessage.Location = New System.Drawing.Point(431, 418)
        Me.BtnSendMessage.Name = "BtnSendMessage"
        Me.BtnSendMessage.Size = New System.Drawing.Size(167, 35)
        Me.BtnSendMessage.TabIndex = 9
        Me.BtnSendMessage.Text = "Send Post"
        Me.BtnSendMessage.UseVisualStyleBackColor = False
        '
        'BtnClear
        '
        Me.BtnClear.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.BtnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClear.ForeColor = System.Drawing.Color.White
        Me.BtnClear.Location = New System.Drawing.Point(753, 418)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.Size = New System.Drawing.Size(84, 35)
        Me.BtnClear.TabIndex = 8
        Me.BtnClear.Text = "Clear"
        Me.BtnClear.UseVisualStyleBackColor = False
        '
        'BtnAttachFile
        '
        Me.BtnAttachFile.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.BtnAttachFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAttachFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAttachFile.ForeColor = System.Drawing.Color.White
        Me.BtnAttachFile.Location = New System.Drawing.Point(604, 418)
        Me.BtnAttachFile.Name = "BtnAttachFile"
        Me.BtnAttachFile.Size = New System.Drawing.Size(110, 35)
        Me.BtnAttachFile.TabIndex = 7
        Me.BtnAttachFile.Text = "Attach File"
        Me.BtnAttachFile.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(415, 49)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(105, 20)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Input Caption"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(415, 147)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 20)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Preview of File"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(601, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 18)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Create Post"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label2.Location = New System.Drawing.Point(32, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Bulletin Board"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label1.Location = New System.Drawing.Point(30, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(245, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Colegio De Montalban"
        '
        'sidebar
        '
        Me.sidebar.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.sidebar.Controls.Add(Me.report_btn)
        Me.sidebar.Controls.Add(Me.Label6)
        Me.sidebar.Controls.Add(Me.PictureBox2)
        Me.sidebar.Controls.Add(Me.PictureBox1)
        Me.sidebar.Controls.Add(Me.Panel4)
        Me.sidebar.Controls.Add(Me.BtnHomePage)
        Me.sidebar.Controls.Add(Me.BtnLogout)
        Me.sidebar.Controls.Add(Me.BtnManageRequest)
        Me.sidebar.Controls.Add(Me.BtnCreatePost)
        Me.sidebar.Dock = System.Windows.Forms.DockStyle.Left
        Me.sidebar.Location = New System.Drawing.Point(0, 34)
        Me.sidebar.Name = "sidebar"
        Me.sidebar.Size = New System.Drawing.Size(57, 483)
        Me.sidebar.TabIndex = 13
        '
        'report_btn
        '
        Me.report_btn.FlatAppearance.BorderSize = 0
        Me.report_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.report_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.report_btn.ForeColor = System.Drawing.Color.White
        Me.report_btn.Image = CType(resources.GetObject("report_btn.Image"), System.Drawing.Image)
        Me.report_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.report_btn.Location = New System.Drawing.Point(13, 373)
        Me.report_btn.Name = "report_btn"
        Me.report_btn.Size = New System.Drawing.Size(226, 54)
        Me.report_btn.TabIndex = 17
        Me.report_btn.Text = "     Reports"
        Me.report_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.report_btn.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(91, 144)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 18)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Admin"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(-7, 159)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(254, 16)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 14
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(71, 38)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Panel4.Location = New System.Drawing.Point(3, 259)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(10, 54)
        Me.Panel4.TabIndex = 3
        '
        'BtnHomePage
        '
        Me.BtnHomePage.FlatAppearance.BorderSize = 0
        Me.BtnHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnHomePage.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHomePage.ForeColor = System.Drawing.Color.White
        Me.BtnHomePage.Image = CType(resources.GetObject("BtnHomePage.Image"), System.Drawing.Image)
        Me.BtnHomePage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnHomePage.Location = New System.Drawing.Point(12, 199)
        Me.BtnHomePage.Name = "BtnHomePage"
        Me.BtnHomePage.Size = New System.Drawing.Size(226, 54)
        Me.BtnHomePage.TabIndex = 10
        Me.BtnHomePage.Text = "     Homepage"
        Me.BtnHomePage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnHomePage.UseVisualStyleBackColor = True
        '
        'BtnLogout
        '
        Me.BtnLogout.FlatAppearance.BorderSize = 0
        Me.BtnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnLogout.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLogout.ForeColor = System.Drawing.Color.White
        Me.BtnLogout.Image = CType(resources.GetObject("BtnLogout.Image"), System.Drawing.Image)
        Me.BtnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnLogout.Location = New System.Drawing.Point(13, 433)
        Me.BtnLogout.Name = "BtnLogout"
        Me.BtnLogout.Size = New System.Drawing.Size(226, 38)
        Me.BtnLogout.TabIndex = 8
        Me.BtnLogout.Text = "     Logout"
        Me.BtnLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnLogout.UseVisualStyleBackColor = True
        '
        'BtnManageRequest
        '
        Me.BtnManageRequest.FlatAppearance.BorderSize = 0
        Me.BtnManageRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnManageRequest.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnManageRequest.ForeColor = System.Drawing.Color.White
        Me.BtnManageRequest.Image = CType(resources.GetObject("BtnManageRequest.Image"), System.Drawing.Image)
        Me.BtnManageRequest.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnManageRequest.Location = New System.Drawing.Point(13, 313)
        Me.BtnManageRequest.Name = "BtnManageRequest"
        Me.BtnManageRequest.Size = New System.Drawing.Size(226, 54)
        Me.BtnManageRequest.TabIndex = 4
        Me.BtnManageRequest.Text = "     Manage Request"
        Me.BtnManageRequest.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnManageRequest.UseVisualStyleBackColor = True
        '
        'BtnCreatePost
        '
        Me.BtnCreatePost.FlatAppearance.BorderSize = 0
        Me.BtnCreatePost.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCreatePost.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCreatePost.ForeColor = System.Drawing.Color.White
        Me.BtnCreatePost.Image = CType(resources.GetObject("BtnCreatePost.Image"), System.Drawing.Image)
        Me.BtnCreatePost.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnCreatePost.Location = New System.Drawing.Point(13, 253)
        Me.BtnCreatePost.Name = "BtnCreatePost"
        Me.BtnCreatePost.Size = New System.Drawing.Size(226, 54)
        Me.BtnCreatePost.TabIndex = 3
        Me.BtnCreatePost.Text = "     Create Post"
        Me.BtnCreatePost.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnCreatePost.UseVisualStyleBackColor = True
        '
        'CreatePostForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(956, 517)
        Me.Controls.Add(Me.sidebar)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "CreatePostForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        Me.Panel1.ResumeLayout(False)
        CType(Me.menu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.deletedata, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbPreview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.sidebar.ResumeLayout(False)
        Me.sidebar.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Close As Button
    Friend WithEvents menu As PictureBox
    Friend WithEvents SidebarTransitionTimer As Timer
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TBoxContent As TextBox
    Friend WithEvents BtnAttachFile As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents BtnSendMessage As Button
    Friend WithEvents BtnClear As Button
    Public WithEvents sidebar As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents BtnHomePage As Button
    Friend WithEvents BtnLogout As Button
    Friend WithEvents BtnManageRequest As Button
    Friend WithEvents BtnCreatePost As Button
    Friend WithEvents pbPreview As PictureBox
    Friend WithEvents report_btn As Button
    Friend WithEvents deletedata As DataGridView
    Friend WithEvents delete As Button
    Friend WithEvents post_id As DataGridViewTextBoxColumn
    Friend WithEvents post As DataGridViewTextBoxColumn
    Friend WithEvents Label7 As Label
End Class
