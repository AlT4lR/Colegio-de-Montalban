﻿Imports System.Data.SqlClient
Imports System.Security.Cryptography
Imports System.Text
Imports System.TimeZoneInfo
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient

Public Class HomePageForm
    Dim isSidebarExpanded As Boolean = False ' To track the current state of the sidebar
    Dim sidebarExpandedWidth As Integer = 238 ' Width of the expanded sidebar
    Dim sidebarCollapsedWidth As Integer = 57 ' Width of the collapsed sidebar
    Dim transitionStep As Integer = 10 ' Width change step for each timer tick

    Private Sub Close_Click(sender As Object, e As EventArgs) Handles Close.Click
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub menu_Click(sender As Object, e As EventArgs) Handles menu.Click
        ToggleSidebar() ' Call the method to toggle the sidebar width
    End Sub

    Private Sub ToggleSidebar()
        ' Toggle the state of the sidebar
        isSidebarExpanded = Not isSidebarExpanded

        ' Start the timer for the transition effect
        SidebarTransitionTimer.Start()
    End Sub

    Private Sub SidebarTransitionTimer_Tick(sender As Object, e As EventArgs) Handles SidebarTransitionTimer.Tick
        If isSidebarExpanded Then
            ' Expand the sidebar
            If sidebar.Width < sidebarExpandedWidth Then
                sidebar.Width += transitionStep
            Else
                ' Stop the timer when the sidebar reaches its expanded width
                SidebarTransitionTimer.Stop()
            End If
        Else
            ' Collapse the sidebar
            If sidebar.Width > sidebarCollapsedWidth Then
                sidebar.Width -= transitionStep
            Else
                ' Stop the timer when the sidebar reaches its collapsed width
                SidebarTransitionTimer.Stop()
            End If
        End If
    End Sub

    Private Sub sidebar_Paint(sender As Object, e As PaintEventArgs)
        ' You can add any custom drawing or painting code for the sidebar here
    End Sub

    Private Sub BtnCreatePost_Click(sender As Object, e As EventArgs) Handles BtnCreatePost.Click
        Me.Hide()
        CreatePostForm.Show()

    End Sub

    Private Sub BtnManageRequest_Click(sender As Object, e As EventArgs) Handles BtnManageRequest.Click
        Me.Hide()
        ManageRequestForm.Show()

    End Sub

    Private Sub report_btn_Click(sender As Object, e As EventArgs) Handles report_btn.Click
        Me.Hide()
        Form6.Show()

    End Sub

    Private Sub insert_Click(sender As Object, e As EventArgs) Handles insert.Click
        ' Database connection details
        Dim connectionString As String = "Server=localhost;Database=bss;Uid=root;"
        Dim connection As New MySqlConnection(connectionString)

        Try
            ' Open the connection
            connection.Open()

            ' SQL insert query without event_id since it will be auto-incremented
            Dim query As String = "INSERT INTO calendar_event (admin_id, event_name, event_start_date) VALUES (@admin_id, @event_name, @event_start_date)"

            ' Create a command
            Dim command As New MySqlCommand(query, connection)

            ' Parameters
            command.Parameters.AddWithValue("@admin_id", 1) ' Assuming a predefined admin_id
            command.Parameters.AddWithValue("@event_name", TextBox1.Text)
            Dim eventDate As String = MonthCalendar1.SelectionStart.ToString("yyyy-MM-dd")
            command.Parameters.AddWithValue("@event_start_date", eventDate)

            ' Execute the command
            Dim result As Integer = command.ExecuteNonQuery()

            ' Check if the insertion was successful
            If result > 0 Then
                MessageBox.Show("Data inserted successfully.")
            Else
                MessageBox.Show("Insertion failed.")
            End If

        Catch ex As MySqlException
            MessageBox.Show("Error: " & ex.Message)
        Finally
            ' Close the connection
            connection.Close()
        End Try

        TextBox1.Clear()
    End Sub

    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click

        Dim result As DialogResult = MessageBox.Show("Are you sure you want to Logout?", "Log Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            LoginForm.Show()
        End If

    End Sub


    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        ' Display or replace Label6 with the admin username
        Dim connectionString As String = "Server=localhost;Database=bss;User ID=root;"
        Using connection As New MySqlConnection(connectionString)
            Try
                connection.Open()

                ' Query to retrieve admin username based on admin ID
                Dim query As String = "SELECT admin_user FROM admin_credentials WHERE admin_id = @admin_id"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@admin_id", GlobalVariables.CurrentAdminID) ' Use the stored admin ID

                    Dim adminUsername As Object = command.ExecuteScalar()

                    If adminUsername IsNot Nothing Then
                        Label4.Text = "Admin: " & adminUsername.ToString()
                    End If
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Finally
                connection.Close()
            End Try
        End Using
    End Sub
    Private Sub changepass_Click(sender As Object, e As EventArgs) Handles changepass.Click
        Dim connectionString As String = "Server=localhost;Database=bss;User ID=root;"
        Dim currentPassword As String = InputBox("Enter your current password:", "Change Password")
        Dim newPassword As String = InputBox("Enter your new password:", "Change Password")

        If currentPassword <> "" AndAlso newPassword <> "" Then
            If ValidateCurrentPassword(CurrentAdminID, currentPassword) Then
                If UpdatePassword(CurrentAdminID, newPassword) Then
                    MessageBox.Show("Password updated successfully.")
                    DisplayAdminCredentials()
                Else
                    MessageBox.Show("Failed to update password. Please try again.")
                End If
            Else
                MessageBox.Show("Incorrect current password. Please try again.")
            End If
        Else
            MessageBox.Show("Current password or new password cannot be empty.")
        End If
    End Sub

    Private Function ValidateCurrentPassword(adminId As Integer, currentPassword As String) As Boolean
        Dim connectionString As String = "Server=localhost;Database=bss;User ID=root;"
        Using connection As New MySqlConnection(connectionString)
            connection.Open()
            Dim query As String = "SELECT admin_pass FROM admin_credentials WHERE admin_id = @AdminId"
            Using command As New MySqlCommand(query, connection)
                command.Parameters.AddWithValue("@AdminId", adminId)
                Dim retrievedPassword As String = Convert.ToString(command.ExecuteScalar())
                If currentPassword = retrievedPassword Then
                    Return True
                Else
                    Return False
                End If
            End Using
        End Using
    End Function

    Private Function UpdatePassword(adminId As Integer, newPassword As String) As Boolean
        Dim connectionString As String = "Server=localhost;Database=bss;User ID=root;"
        Using connection As New MySqlConnection(connectionString)
            connection.Open()
            Dim query As String = "UPDATE admin_credentials SET admin_pass = @NewPassword WHERE admin_id = @AdminId"
            Using command As New MySqlCommand(query, connection)
                command.Parameters.AddWithValue("@NewPassword", newPassword)
                command.Parameters.AddWithValue("@AdminId", adminId)
                Dim rowsAffected As Integer = command.ExecuteNonQuery()
                If rowsAffected > 0 Then
                    Return True
                Else
                    Return False
                End If
            End Using
        End Using
    End Function

    Private Sub adminuser_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub adminpass_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub HomePageForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DisplayAdminCredentials()
    End Sub
    Private Sub DisplayAdminCredentials()
        Dim adminId As Integer = CurrentAdminID
        Dim credentials As Tuple(Of String, String) = GetAdminCredentials(adminId)
        If credentials IsNot Nothing Then
            adminuser.Text = credentials.Item1 ' admin_user
            adminpass.Text = credentials.Item2 ' admin_pass
        End If
    End Sub

    Private Function GetAdminCredentials(adminId As Integer) As Tuple(Of String, String)
        Dim adminCredentials As Tuple(Of String, String) = Nothing
        Dim connectionString As String = "Server=localhost;Database=bss;User ID=root;"
        Using connection As New MySqlConnection(connectionString)
            connection.Open()
            Dim query As String = "SELECT admin_user, admin_pass FROM admin_credentials WHERE admin_id = @AdminId"
            Using command As New MySqlCommand(query, connection)
                command.Parameters.AddWithValue("@AdminId", adminId)
                Dim reader As MySqlDataReader = command.ExecuteReader()
                If reader.Read() Then
                    Dim adminUser As String = reader("admin_user").ToString()
                    Dim adminPass As String = reader("admin_pass").ToString()
                    adminCredentials = New Tuple(Of String, String)(adminUser, adminPass)
                End If
                reader.Close()
            End Using
        End Using
        Return adminCredentials
    End Function

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub
End Class
