﻿Imports System.Security.Cryptography
Imports Microsoft.VisualBasic.ApplicationServices
Imports MySql.Data.MySqlClient
Imports Mysqlx
Module GlobalVariables
    Public CurrentAdminID As Integer
End Module

Public Class LoginForm
    Dim mysqlcon As MySqlConnection
    Dim command As MySqlCommand
    Private Sub LblClose_Click_1(sender As Object, e As EventArgs) Handles LblClose.Click

        Dim result As DialogResult = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub TBoxUsername_TextChanged(sender As Object, e As EventArgs) Handles TBoxUsername.TextChanged

    End Sub

    Private Sub TBoxPassword_TextChanged(sender As Object, e As EventArgs) Handles TBoxPassword.TextChanged

    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        mysqlcon = New MySqlConnection

        mysqlcon.ConnectionString = "Server=localhost;Database=bss;User ID=root;"

        Try
            mysqlcon.Open()
            Dim query As String

            query = "SELECT admin_id FROM admin_credentials WHERE admin_user=@username AND admin_pass=@password"
            Using command As New MySqlCommand(query, mysqlcon)
                command.Parameters.AddWithValue("@username", TBoxUsername.Text)
                command.Parameters.AddWithValue("@password", TBoxPassword.Text)

                Using reader As MySqlDataReader = command.ExecuteReader()
                    If reader.HasRows Then
                        reader.Read()
                        GlobalVariables.CurrentAdminID = reader.GetInt32("admin_id")
                        MessageBox.Show("Login successful!")
                        Me.Hide()
                        CreatePostForm.Show()
                    Else
                        MessageBox.Show("Invalid username or password.")
                    End If
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            mysqlcon.Close()
        End Try
        TBoxUsername.Clear()
        TBoxPassword.Clear()

    End Sub



    Private Sub LblSignUp_Click(sender As Object, e As EventArgs)
        Me.Hide()
        RegistrationForm.Show()

    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs)

    End Sub
End Class
