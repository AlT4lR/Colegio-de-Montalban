﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HomePageForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HomePageForm))
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.insert = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.changepass = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.adminuser = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.adminpass = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Close = New System.Windows.Forms.Button()
        Me.menu = New System.Windows.Forms.PictureBox()
        Me.SidebarTransitionTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.sidebar = New System.Windows.Forms.Panel()
        Me.report_btn = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.BtnHomePage = New System.Windows.Forms.Button()
        Me.BtnLogout = New System.Windows.Forms.Button()
        Me.BtnManageRequest = New System.Windows.Forms.Button()
        Me.BtnCreatePost = New System.Windows.Forms.Button()
        Me.Panel3.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        CType(Me.menu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.sidebar.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Panel5)
        Me.Panel3.Controls.Add(Me.Panel2)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Location = New System.Drawing.Point(57, 34)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(899, 483)
        Me.Panel3.TabIndex = 11
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.MonthCalendar1)
        Me.Panel5.Controls.Add(Me.Label3)
        Me.Panel5.Controls.Add(Me.insert)
        Me.Panel5.Controls.Add(Me.Label5)
        Me.Panel5.Controls.Add(Me.TextBox1)
        Me.Panel5.Location = New System.Drawing.Point(558, 22)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(315, 428)
        Me.Panel5.TabIndex = 18
        '
        'MonthCalendar1
        '
        Me.MonthCalendar1.BackColor = System.Drawing.Color.PaleGreen
        Me.MonthCalendar1.Location = New System.Drawing.Point(48, 180)
        Me.MonthCalendar1.Name = "MonthCalendar1"
        Me.MonthCalendar1.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(75, 89)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(160, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "CDM EVENTS"
        '
        'insert
        '
        Me.insert.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.insert.FlatAppearance.BorderSize = 0
        Me.insert.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.insert.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.insert.ForeColor = System.Drawing.SystemColors.Control
        Me.insert.Location = New System.Drawing.Point(48, 354)
        Me.insert.Name = "insert"
        Me.insert.Size = New System.Drawing.Size(227, 39)
        Me.insert.TabIndex = 9
        Me.insert.Text = "Add Event"
        Me.insert.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(125, 121)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 15)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Event Title"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(48, 144)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(227, 20)
        Me.TextBox1.TabIndex = 4
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.changepass)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Panel6)
        Me.Panel2.Controls.Add(Me.Panel7)
        Me.Panel2.Location = New System.Drawing.Point(35, 95)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(273, 218)
        Me.Panel2.TabIndex = 17
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Yu Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(64, 18)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(136, 25)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Admin Profile"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Gray
        Me.Label7.Location = New System.Drawing.Point(28, 113)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(66, 17)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Password"
        '
        'changepass
        '
        Me.changepass.BackColor = System.Drawing.Color.LimeGreen
        Me.changepass.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.changepass.FlatAppearance.BorderSize = 0
        Me.changepass.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime
        Me.changepass.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime
        Me.changepass.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.changepass.Font = New System.Drawing.Font("Yu Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.changepass.ForeColor = System.Drawing.Color.White
        Me.changepass.Location = New System.Drawing.Point(82, 164)
        Me.changepass.Name = "changepass"
        Me.changepass.Size = New System.Drawing.Size(118, 33)
        Me.changepass.TabIndex = 12
        Me.changepass.Text = "Change Password"
        Me.changepass.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Gray
        Me.Label6.Location = New System.Drawing.Point(27, 60)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(69, 17)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Username"
        '
        'Panel6
        '
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.Button2)
        Me.Panel6.Controls.Add(Me.adminuser)
        Me.Panel6.Location = New System.Drawing.Point(30, 80)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(219, 22)
        Me.Panel6.TabIndex = 17
        '
        'Button2
        '
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Black
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(4, 1)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(22, 17)
        Me.Button2.TabIndex = 19
        Me.Button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button2.UseVisualStyleBackColor = True
        '
        'adminuser
        '
        Me.adminuser.AutoSize = True
        Me.adminuser.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.adminuser.Location = New System.Drawing.Point(35, 1)
        Me.adminuser.Name = "adminuser"
        Me.adminuser.Size = New System.Drawing.Size(44, 17)
        Me.adminuser.TabIndex = 13
        Me.adminuser.Text = "admin"
        '
        'Panel7
        '
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.Button3)
        Me.Panel7.Controls.Add(Me.adminpass)
        Me.Panel7.Location = New System.Drawing.Point(30, 131)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(219, 22)
        Me.Panel7.TabIndex = 18
        '
        'Button3
        '
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.Black
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.Location = New System.Drawing.Point(4, 1)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(22, 17)
        Me.Button3.TabIndex = 20
        Me.Button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button3.UseVisualStyleBackColor = True
        '
        'adminpass
        '
        Me.adminpass.AutoSize = True
        Me.adminpass.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.adminpass.Location = New System.Drawing.Point(35, 1)
        Me.adminpass.Name = "adminpass"
        Me.adminpass.Size = New System.Drawing.Size(44, 17)
        Me.adminpass.TabIndex = 14
        Me.adminpass.Text = "admin"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label2.Location = New System.Drawing.Point(32, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Bulletin Board"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label1.Location = New System.Drawing.Point(30, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(245, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Colegio De Montalban"
        '
        'Close
        '
        Me.Close.FlatAppearance.BorderSize = 0
        Me.Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Close.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Close.ForeColor = System.Drawing.Color.Black
        Me.Close.Image = CType(resources.GetObject("Close.Image"), System.Drawing.Image)
        Me.Close.Location = New System.Drawing.Point(921, 8)
        Me.Close.Name = "Close"
        Me.Close.Size = New System.Drawing.Size(22, 17)
        Me.Close.TabIndex = 11
        Me.Close.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Close.UseVisualStyleBackColor = True
        '
        'menu
        '
        Me.menu.Image = CType(resources.GetObject("menu.Image"), System.Drawing.Image)
        Me.menu.Location = New System.Drawing.Point(12, 5)
        Me.menu.Name = "menu"
        Me.menu.Size = New System.Drawing.Size(45, 23)
        Me.menu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.menu.TabIndex = 1
        Me.menu.TabStop = False
        '
        'SidebarTransitionTimer
        '
        Me.SidebarTransitionTimer.Interval = 10
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Close)
        Me.Panel1.Controls.Add(Me.menu)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(956, 34)
        Me.Panel1.TabIndex = 9
        '
        'sidebar
        '
        Me.sidebar.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.sidebar.Controls.Add(Me.report_btn)
        Me.sidebar.Controls.Add(Me.Label4)
        Me.sidebar.Controls.Add(Me.PictureBox2)
        Me.sidebar.Controls.Add(Me.PictureBox1)
        Me.sidebar.Controls.Add(Me.Panel4)
        Me.sidebar.Controls.Add(Me.BtnHomePage)
        Me.sidebar.Controls.Add(Me.BtnLogout)
        Me.sidebar.Controls.Add(Me.BtnManageRequest)
        Me.sidebar.Controls.Add(Me.BtnCreatePost)
        Me.sidebar.Dock = System.Windows.Forms.DockStyle.Left
        Me.sidebar.Location = New System.Drawing.Point(0, 34)
        Me.sidebar.Name = "sidebar"
        Me.sidebar.Size = New System.Drawing.Size(57, 483)
        Me.sidebar.TabIndex = 12
        '
        'report_btn
        '
        Me.report_btn.FlatAppearance.BorderSize = 0
        Me.report_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.report_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.report_btn.ForeColor = System.Drawing.Color.White
        Me.report_btn.Image = CType(resources.GetObject("report_btn.Image"), System.Drawing.Image)
        Me.report_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.report_btn.Location = New System.Drawing.Point(13, 373)
        Me.report_btn.Name = "report_btn"
        Me.report_btn.Size = New System.Drawing.Size(226, 54)
        Me.report_btn.TabIndex = 17
        Me.report_btn.Text = "     Reports"
        Me.report_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.report_btn.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(91, 144)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 18)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Admin"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(-15, 165)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(254, 16)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 14
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(71, 38)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Panel4.Location = New System.Drawing.Point(3, 194)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(10, 54)
        Me.Panel4.TabIndex = 3
        '
        'BtnHomePage
        '
        Me.BtnHomePage.FlatAppearance.BorderSize = 0
        Me.BtnHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnHomePage.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHomePage.ForeColor = System.Drawing.Color.White
        Me.BtnHomePage.Image = CType(resources.GetObject("BtnHomePage.Image"), System.Drawing.Image)
        Me.BtnHomePage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnHomePage.Location = New System.Drawing.Point(13, 194)
        Me.BtnHomePage.Name = "BtnHomePage"
        Me.BtnHomePage.Size = New System.Drawing.Size(226, 54)
        Me.BtnHomePage.TabIndex = 10
        Me.BtnHomePage.Text = "     Homepage"
        Me.BtnHomePage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnHomePage.UseVisualStyleBackColor = True
        '
        'BtnLogout
        '
        Me.BtnLogout.FlatAppearance.BorderSize = 0
        Me.BtnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnLogout.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLogout.ForeColor = System.Drawing.Color.White
        Me.BtnLogout.Image = CType(resources.GetObject("BtnLogout.Image"), System.Drawing.Image)
        Me.BtnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnLogout.Location = New System.Drawing.Point(13, 433)
        Me.BtnLogout.Name = "BtnLogout"
        Me.BtnLogout.Size = New System.Drawing.Size(226, 38)
        Me.BtnLogout.TabIndex = 8
        Me.BtnLogout.Text = "     Logout"
        Me.BtnLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnLogout.UseVisualStyleBackColor = True
        '
        'BtnManageRequest
        '
        Me.BtnManageRequest.FlatAppearance.BorderSize = 0
        Me.BtnManageRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnManageRequest.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnManageRequest.ForeColor = System.Drawing.Color.White
        Me.BtnManageRequest.Image = CType(resources.GetObject("BtnManageRequest.Image"), System.Drawing.Image)
        Me.BtnManageRequest.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnManageRequest.Location = New System.Drawing.Point(12, 319)
        Me.BtnManageRequest.Name = "BtnManageRequest"
        Me.BtnManageRequest.Size = New System.Drawing.Size(226, 54)
        Me.BtnManageRequest.TabIndex = 4
        Me.BtnManageRequest.Text = "     Manage Request"
        Me.BtnManageRequest.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnManageRequest.UseVisualStyleBackColor = True
        '
        'BtnCreatePost
        '
        Me.BtnCreatePost.FlatAppearance.BorderSize = 0
        Me.BtnCreatePost.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCreatePost.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCreatePost.ForeColor = System.Drawing.Color.White
        Me.BtnCreatePost.Image = CType(resources.GetObject("BtnCreatePost.Image"), System.Drawing.Image)
        Me.BtnCreatePost.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnCreatePost.Location = New System.Drawing.Point(13, 259)
        Me.BtnCreatePost.Name = "BtnCreatePost"
        Me.BtnCreatePost.Size = New System.Drawing.Size(226, 54)
        Me.BtnCreatePost.TabIndex = 3
        Me.BtnCreatePost.Text = "     Create Post"
        Me.BtnCreatePost.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnCreatePost.UseVisualStyleBackColor = True
        '
        'HomePageForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(956, 517)
        Me.Controls.Add(Me.sidebar)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "HomePageForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form4"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        CType(Me.menu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.sidebar.ResumeLayout(False)
        Me.sidebar.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Close As Button
    Friend WithEvents menu As PictureBox
    Friend WithEvents SidebarTransitionTimer As Timer
    Friend WithEvents Panel1 As Panel
    Public WithEvents sidebar As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents BtnHomePage As Button
    Friend WithEvents BtnLogout As Button
    Friend WithEvents BtnManageRequest As Button
    Friend WithEvents BtnCreatePost As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents MonthCalendar1 As MonthCalendar
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents insert As Button
    Friend WithEvents report_btn As Button
    Friend WithEvents changepass As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents adminpass As Label
    Friend WithEvents adminuser As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
End Class
