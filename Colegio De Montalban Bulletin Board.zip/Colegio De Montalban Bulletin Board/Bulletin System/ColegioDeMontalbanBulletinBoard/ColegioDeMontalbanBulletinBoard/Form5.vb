﻿Imports MySql.Data.MySqlClient

Public Class RegistrationForm
    Dim mysqlcon As MySqlConnection
    Dim command As MySqlCommand
    Private Sub LblLogIn_Click(sender As Object, e As EventArgs) Handles LblLogIn.Click
        Me.Hide()
        LoginForm.Show()

    End Sub

    Private Sub BtnRegister_Click(sender As Object, e As EventArgs) Handles BtnRegister.Click
        mysqlcon = New MySqlConnection

        mysqlcon.ConnectionString = "Server=localhost;Database=bss;User ID=root;"

        Try
            mysqlcon.Open()
            Dim query As String

            ' Check if the username already exists
            query = "SELECT COUNT(*) FROM admin_credentials WHERE admin_user=@username"
            Using checkCommand As New MySqlCommand(query, mysqlcon)
                checkCommand.Parameters.AddWithValue("@username", TBoxUsername.Text)
                Dim count As Integer = Convert.ToInt32(checkCommand.ExecuteScalar())

                If count > 0 Then
                    MessageBox.Show("Username already exists. Please choose a different username.")
                    Exit Sub
                End If
            End Using

            ' Insert new user credentials
            query = "INSERT INTO admin_credentials (admin_user, admin_pass) VALUES (@username, @password)"
            Using command As New MySqlCommand(query, mysqlcon)
                command.Parameters.AddWithValue("@username", TBoxUsername.Text)
                command.Parameters.AddWithValue("@password", TBoxPassword.Text)

                Dim result As Integer = command.ExecuteNonQuery()

                ' Check if the insertion was successful
                If result > 0 Then
                    MessageBox.Show("Registration successful!")
                Else
                    MessageBox.Show("Registration failed.")
                End If
            End Using

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            mysqlcon.Close()
        End Try
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click

    End Sub

    Private Sub LblClose_Click(sender As Object, e As EventArgs) Handles LblClose.Click
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub
End Class