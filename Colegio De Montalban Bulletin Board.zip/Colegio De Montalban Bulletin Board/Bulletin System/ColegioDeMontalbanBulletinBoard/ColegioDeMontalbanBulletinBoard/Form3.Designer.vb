﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ManageRequestForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ManageRequestForm))
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.DenyButton = New System.Windows.Forms.Button()
        Me.ApproveButton = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.RequestIdColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.user_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.request = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SidebarTransitionTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Close = New System.Windows.Forms.Button()
        Me.menu = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.sidebar = New System.Windows.Forms.Panel()
        Me.report_btn = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.BtnHomePage = New System.Windows.Forms.Button()
        Me.BtnLogout = New System.Windows.Forms.Button()
        Me.BtnManageRequest = New System.Windows.Forms.Button()
        Me.BtnCreatePost = New System.Windows.Forms.Button()
        Me.Panel3.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.menu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.sidebar.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(498, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(122, 21)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Request Status"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(32, 102)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(134, 18)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Manage Request"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label2.Location = New System.Drawing.Point(32, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Bulletin Board"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label1.Location = New System.Drawing.Point(30, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(245, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Colegio De Montalban"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.DenyButton)
        Me.Panel3.Controls.Add(Me.ApproveButton)
        Me.Panel3.Controls.Add(Me.DataGridView1)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Location = New System.Drawing.Point(57, 34)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(899, 483)
        Me.Panel3.TabIndex = 8
        '
        'DenyButton
        '
        Me.DenyButton.BackColor = System.Drawing.Color.White
        Me.DenyButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DenyButton.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DenyButton.ForeColor = System.Drawing.Color.Black
        Me.DenyButton.Location = New System.Drawing.Point(502, 337)
        Me.DenyButton.Name = "DenyButton"
        Me.DenyButton.Size = New System.Drawing.Size(168, 36)
        Me.DenyButton.TabIndex = 14
        Me.DenyButton.Text = "Deny"
        Me.DenyButton.UseVisualStyleBackColor = False
        '
        'ApproveButton
        '
        Me.ApproveButton.BackColor = System.Drawing.Color.LimeGreen
        Me.ApproveButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ApproveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ApproveButton.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ApproveButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ApproveButton.Location = New System.Drawing.Point(678, 337)
        Me.ApproveButton.Name = "ApproveButton"
        Me.ApproveButton.Size = New System.Drawing.Size(168, 36)
        Me.ApproveButton.TabIndex = 13
        Me.ApproveButton.Text = "Approve"
        Me.ApproveButton.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RequestIdColumn, Me.user_id, Me.request})
        Me.DataGridView1.Location = New System.Drawing.Point(502, 52)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(344, 273)
        Me.DataGridView1.TabIndex = 12
        '
        'RequestIdColumn
        '
        Me.RequestIdColumn.DataPropertyName = "request_id"
        Me.RequestIdColumn.HeaderText = "requestId"
        Me.RequestIdColumn.Name = "RequestIdColumn"
        '
        'user_id
        '
        Me.user_id.DataPropertyName = "user_id"
        Me.user_id.HeaderText = "userId"
        Me.user_id.Name = "user_id"
        '
        'request
        '
        Me.request.DataPropertyName = "request"
        Me.request.HeaderText = "resquest"
        Me.request.Name = "request"
        '
        'SidebarTransitionTimer
        '
        Me.SidebarTransitionTimer.Interval = 10
        '
        'Close
        '
        Me.Close.FlatAppearance.BorderSize = 0
        Me.Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Close.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Close.ForeColor = System.Drawing.Color.Black
        Me.Close.Image = CType(resources.GetObject("Close.Image"), System.Drawing.Image)
        Me.Close.Location = New System.Drawing.Point(921, 8)
        Me.Close.Name = "Close"
        Me.Close.Size = New System.Drawing.Size(22, 17)
        Me.Close.TabIndex = 11
        Me.Close.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Close.UseVisualStyleBackColor = True
        '
        'menu
        '
        Me.menu.Image = CType(resources.GetObject("menu.Image"), System.Drawing.Image)
        Me.menu.Location = New System.Drawing.Point(12, 5)
        Me.menu.Name = "menu"
        Me.menu.Size = New System.Drawing.Size(45, 23)
        Me.menu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.menu.TabIndex = 1
        Me.menu.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Close)
        Me.Panel1.Controls.Add(Me.menu)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(956, 34)
        Me.Panel1.TabIndex = 6
        '
        'sidebar
        '
        Me.sidebar.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.sidebar.Controls.Add(Me.report_btn)
        Me.sidebar.Controls.Add(Me.Label6)
        Me.sidebar.Controls.Add(Me.PictureBox2)
        Me.sidebar.Controls.Add(Me.PictureBox1)
        Me.sidebar.Controls.Add(Me.Panel4)
        Me.sidebar.Controls.Add(Me.BtnHomePage)
        Me.sidebar.Controls.Add(Me.BtnLogout)
        Me.sidebar.Controls.Add(Me.BtnManageRequest)
        Me.sidebar.Controls.Add(Me.BtnCreatePost)
        Me.sidebar.Dock = System.Windows.Forms.DockStyle.Left
        Me.sidebar.Location = New System.Drawing.Point(0, 34)
        Me.sidebar.Name = "sidebar"
        Me.sidebar.Size = New System.Drawing.Size(57, 483)
        Me.sidebar.TabIndex = 13
        '
        'report_btn
        '
        Me.report_btn.FlatAppearance.BorderSize = 0
        Me.report_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.report_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.report_btn.ForeColor = System.Drawing.Color.White
        Me.report_btn.Image = CType(resources.GetObject("report_btn.Image"), System.Drawing.Image)
        Me.report_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.report_btn.Location = New System.Drawing.Point(12, 373)
        Me.report_btn.Name = "report_btn"
        Me.report_btn.Size = New System.Drawing.Size(226, 54)
        Me.report_btn.TabIndex = 17
        Me.report_btn.Text = "     Reports"
        Me.report_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.report_btn.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(91, 144)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 18)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Admin"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(-7, 159)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(254, 16)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 14
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(71, 38)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Panel4.Location = New System.Drawing.Point(3, 319)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(10, 54)
        Me.Panel4.TabIndex = 3
        '
        'BtnHomePage
        '
        Me.BtnHomePage.FlatAppearance.BorderSize = 0
        Me.BtnHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnHomePage.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHomePage.ForeColor = System.Drawing.Color.White
        Me.BtnHomePage.Image = CType(resources.GetObject("BtnHomePage.Image"), System.Drawing.Image)
        Me.BtnHomePage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnHomePage.Location = New System.Drawing.Point(13, 194)
        Me.BtnHomePage.Name = "BtnHomePage"
        Me.BtnHomePage.Size = New System.Drawing.Size(226, 54)
        Me.BtnHomePage.TabIndex = 10
        Me.BtnHomePage.Text = "     Homepage"
        Me.BtnHomePage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnHomePage.UseVisualStyleBackColor = True
        '
        'BtnLogout
        '
        Me.BtnLogout.FlatAppearance.BorderSize = 0
        Me.BtnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnLogout.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLogout.ForeColor = System.Drawing.Color.White
        Me.BtnLogout.Image = CType(resources.GetObject("BtnLogout.Image"), System.Drawing.Image)
        Me.BtnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnLogout.Location = New System.Drawing.Point(13, 433)
        Me.BtnLogout.Name = "BtnLogout"
        Me.BtnLogout.Size = New System.Drawing.Size(226, 38)
        Me.BtnLogout.TabIndex = 8
        Me.BtnLogout.Text = "     Logout"
        Me.BtnLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnLogout.UseVisualStyleBackColor = True
        '
        'BtnManageRequest
        '
        Me.BtnManageRequest.FlatAppearance.BorderSize = 0
        Me.BtnManageRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnManageRequest.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnManageRequest.ForeColor = System.Drawing.Color.White
        Me.BtnManageRequest.Image = CType(resources.GetObject("BtnManageRequest.Image"), System.Drawing.Image)
        Me.BtnManageRequest.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnManageRequest.Location = New System.Drawing.Point(13, 319)
        Me.BtnManageRequest.Name = "BtnManageRequest"
        Me.BtnManageRequest.Size = New System.Drawing.Size(226, 54)
        Me.BtnManageRequest.TabIndex = 4
        Me.BtnManageRequest.Text = "     Manage Request"
        Me.BtnManageRequest.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnManageRequest.UseVisualStyleBackColor = True
        '
        'BtnCreatePost
        '
        Me.BtnCreatePost.FlatAppearance.BorderSize = 0
        Me.BtnCreatePost.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCreatePost.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCreatePost.ForeColor = System.Drawing.Color.White
        Me.BtnCreatePost.Image = CType(resources.GetObject("BtnCreatePost.Image"), System.Drawing.Image)
        Me.BtnCreatePost.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnCreatePost.Location = New System.Drawing.Point(13, 259)
        Me.BtnCreatePost.Name = "BtnCreatePost"
        Me.BtnCreatePost.Size = New System.Drawing.Size(226, 54)
        Me.BtnCreatePost.TabIndex = 3
        Me.BtnCreatePost.Text = "     Create Post"
        Me.BtnCreatePost.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnCreatePost.UseVisualStyleBackColor = True
        '
        'ManageRequestForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(956, 517)
        Me.Controls.Add(Me.sidebar)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "ManageRequestForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form3"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.menu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.sidebar.ResumeLayout(False)
        Me.sidebar.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents SidebarTransitionTimer As Timer
    Friend WithEvents Close As Button
    Friend WithEvents menu As PictureBox
    Friend WithEvents Panel1 As Panel
    Public WithEvents sidebar As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents BtnHomePage As Button
    Friend WithEvents BtnLogout As Button
    Friend WithEvents BtnManageRequest As Button
    Friend WithEvents BtnCreatePost As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents RequestIdColumn As DataGridViewTextBoxColumn
    Friend WithEvents user_id As DataGridViewTextBoxColumn
    Friend WithEvents request As DataGridViewTextBoxColumn
    Friend WithEvents DenyButton As Button
    Friend WithEvents ApproveButton As Button
    Friend WithEvents report_btn As Button
End Class
