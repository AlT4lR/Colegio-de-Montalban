﻿Imports System.TimeZoneInfo
Imports MySql.Data.MySqlClient

Public Class ManageRequestForm
    Dim isSidebarExpanded As Boolean = False ' To track the current state of the sidebar
    Dim sidebarExpandedWidth As Integer = 238 ' Width of the expanded sidebar
    Dim sidebarCollapsedWidth As Integer = 57 ' Width of the collapsed sidebar
    Dim transitionStep As Integer = 10 ' Width change step for each timer tick

    Private Sub Close_Click(sender As Object, e As EventArgs) Handles Close.Click
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub menu_Click(sender As Object, e As EventArgs) Handles menu.Click
        ToggleSidebar() ' Call the method to toggle the sidebar width
    End Sub

    Private Sub ToggleSidebar()
        ' Toggle the state of the sidebar
        isSidebarExpanded = Not isSidebarExpanded

        ' Start the timer for the transition effect
        SidebarTransitionTimer.Start()
    End Sub

    Private Sub SidebarTransitionTimer_Tick(sender As Object, e As EventArgs) Handles SidebarTransitionTimer.Tick
        If isSidebarExpanded Then
            ' Expand the sidebar
            If sidebar.Width < sidebarExpandedWidth Then
                sidebar.Width += transitionStep
            Else
                ' Stop the timer when the sidebar reaches its expanded width
                SidebarTransitionTimer.Stop()
            End If
        Else
            ' Collapse the sidebar
            If sidebar.Width > sidebarCollapsedWidth Then
                sidebar.Width -= transitionStep
            Else
                ' Stop the timer when the sidebar reaches its collapsed width
                SidebarTransitionTimer.Stop()
            End If
        End If
    End Sub

    Private Sub sidebar_Paint(sender As Object, e As PaintEventArgs)
        ' You can add any custom drawing or painting code for the sidebar here
    End Sub

    Private Sub BtnCreatePost_Click(sender As Object, e As EventArgs) Handles BtnCreatePost.Click
        Me.Hide()
        CreatePostForm.Show()

    End Sub

    Private Sub BtnHomePage_Click(sender As Object, e As EventArgs) Handles BtnHomePage.Click
        Me.Hide()
        HomePageForm.Show()

    End Sub

    Private Sub report_btn_Click(sender As Object, e As EventArgs) Handles report_btn.Click
        Me.Hide()
        Form6.Show()

    End Sub

    Dim connectionString As String = "Server=localhost;Database=bss;Uid=root;"

    Private loggedInAdminId As Integer ' You need to set this when the admin logs in

    Private Sub ManageRequestsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadPendingRequests()
    End Sub

    Private Sub LoadPendingRequests()
        Using connection As New MySqlConnection(connectionString)
            connection.Open()
            Dim selectCommand As String = "SELECT request_id, user_id, request FROM manage_request WHERE status = 'pending' or status = 'posted'"
            Dim sqlCommand As New MySqlCommand(selectCommand, connection)
            Dim dataReader As MySqlDataReader = sqlCommand.ExecuteReader()

            While dataReader.Read()
                Dim requestId As Integer = Convert.ToInt32(dataReader("request_id"))
                Dim userId As Integer = Convert.ToInt32(dataReader("user_id"))
                Dim request As String = dataReader("request").ToString()

                ' Display the pending requests in the UI, e.g., in a DataGridView
                DataGridView1.Rows.Add(requestId, userId, request)
            End While

            dataReader.Close()
        End Using
    End Sub

    Private Sub ApproveRequest(requestId As Integer)
        UpdateRequestStatus(requestId, "approved")
        ' Optionally, you can notify the user that their request has been approved
        MessageBox.Show("User already approved")
    End Sub

    Private Sub DenyRequest(requestId As Integer)
        UpdateRequestStatus(requestId, "denied")
        ' Optionally, you can notify the user that their request has been denied
        MessageBox.Show("You denied the user")
    End Sub

    Private Sub UpdateRequestStatus(requestId As Integer, status As String)
        Using connection As New MySqlConnection(connectionString)
            connection.Open()
            Dim updateCommand As String = "UPDATE manage_request SET status = @status, admin_id = @adminId WHERE request_id = @requestId"
            Dim sqlCommand As New MySqlCommand(updateCommand, connection)
            sqlCommand.Parameters.AddWithValue("@status", status)
            sqlCommand.Parameters.AddWithValue("@adminId", loggedInAdminId)
            sqlCommand.Parameters.AddWithValue("@requestId", requestId)
            sqlCommand.ExecuteNonQuery()
        End Using
    End Sub

    Private Sub ApproveButton_Click(sender As Object, e As EventArgs) Handles ApproveButton.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim requestId As Integer = Convert.ToInt32(DataGridView1.SelectedRows(0).Cells("RequestIdColumn").Value)
            ApproveRequest(requestId)
            LoadPendingRequests() ' Reload pending requests after approval
        Else
            MessageBox.Show("Please select a request to approve.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub DenyButton_Click(sender As Object, e As EventArgs) Handles DenyButton.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim requestId As Integer = Convert.ToInt32(DataGridView1.SelectedRows(0).Cells("RequestIdColumn").Value)
            DenyRequest(requestId)
            LoadPendingRequests() ' Reload pending requests after denial
        Else
            MessageBox.Show("Please select a request to deny.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click

        Dim result As DialogResult = MessageBox.Show("Are you sure you want to Logout?", "Log Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            LoginForm.Show()
        End If

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        ' Display or replace Label6 with the admin username
        Dim connectionString As String = "Server=localhost;Database=bss;User ID=root;"
        Using connection As New MySqlConnection(connectionString)
            Try
                connection.Open()

                ' Query to retrieve admin username based on admin ID
                Dim query As String = "SELECT admin_user FROM admin_credentials WHERE admin_id = @admin_id"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@admin_id", GlobalVariables.CurrentAdminID) ' Use the stored admin ID

                    Dim adminUsername As Object = command.ExecuteScalar()

                    If adminUsername IsNot Nothing Then
                        Label6.Text = "Admin: " & adminUsername.ToString()
                    End If
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Finally
                connection.Close()
            End Try
        End Using
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub
End Class
