﻿Imports System.TimeZoneInfo
Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Drawing
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel

Public Class CreatePostForm
    Dim isSidebarExpanded As Boolean = False
    Dim sidebarExpandedWidth As Integer = 238
    Dim sidebarCollapsedWidth As Integer = 57
    Dim transitionStep As Integer = 10

    Private selectedFilePath As String = String.Empty
    Private selectedFileType As String = String.Empty


    Private Sub Close_Click(sender As Object, e As EventArgs) Handles Close.Click
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub menu_Click(sender As Object, e As EventArgs) Handles menu.Click
        ToggleSidebar() ' Call the method to toggle the sidebar width
    End Sub

    Private Sub ToggleSidebar()
        ' Toggle the state of the sidebar
        isSidebarExpanded = Not isSidebarExpanded

        ' Start the timer for the transition effect
        SidebarTransitionTimer.Start()
    End Sub

    Private Sub SidebarTransitionTimer_Tick(sender As Object, e As EventArgs) Handles SidebarTransitionTimer.Tick
        If isSidebarExpanded Then
            ' Expand the sidebar
            If sidebar.Width < sidebarExpandedWidth Then
                sidebar.Width += transitionStep
            Else
                ' Stop the timer when the sidebar reaches its expanded width
                SidebarTransitionTimer.Stop()
            End If
        Else
            ' Collapse the sidebar
            If sidebar.Width > sidebarCollapsedWidth Then
                sidebar.Width -= transitionStep
            Else
                ' Stop the timer when the sidebar reaches its collapsed width
                SidebarTransitionTimer.Stop()
            End If
        End If
    End Sub

    Private Sub sidebar_Paint(sender As Object, e As PaintEventArgs)
        ' You can add any custom drawing or painting code for the sidebar here
    End Sub

    Private Sub BtnAttachFile_Click(sender As Object, e As EventArgs) Handles BtnAttachFile.Click
        Using openFileDialog As New OpenFileDialog()
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.webp|Video Files|*.mp4;*.avi"
            If openFileDialog.ShowDialog() = DialogResult.OK Then
                selectedFilePath = openFileDialog.FileName
                selectedFileType = Path.GetExtension(selectedFilePath).ToLower()
                If selectedFileType = ".jpg" Or selectedFileType = ".jpeg" Or selectedFileType = ".png" Or selectedFileType = ".webp" Then
                    Try
                        Using imgStream As New FileStream(selectedFilePath, FileMode.Open, FileAccess.Read)
                            pbPreview.Image = Image.FromStream(imgStream)
                        End Using
                    Catch ex As Exception
                        MessageBox.Show("Error loading image: " & ex.Message)
                    End Try
                ElseIf selectedFileType = ".mp4" Or selectedFileType = ".avi" Then
                    MessageBox.Show("Video selected: " & selectedFilePath)
                End If
            End If
        End Using
    End Sub

    Private Sub BtnSendMessage_Click(sender As Object, e As EventArgs) Handles BtnSendMessage.Click
        Dim connectionString As String = "Server=localhost;Database=bss;User ID=root;"
        Using connection As New MySqlConnection(connectionString)
            Try
                connection.Open()

                ' Define the destination directory for the uploads
                Dim websitePath As String = "C:\xampp\htdocs\bulletin\uploads\uploads" ' Ensure this path points to your XAMPP uploads directory
                Dim mediaFileName As String = Path.GetFileName(selectedFilePath)
                Dim mediaDestinationPath As String = Path.Combine("uploads", mediaFileName)
                Dim absolutePath As String = Path.Combine(websitePath, mediaFileName)

                ' Ensure the uploads directory exists
                If Not Directory.Exists(websitePath) Then
                    Directory.CreateDirectory(websitePath)
                End If

                ' Copy the file to the uploads directory
                File.Copy(selectedFilePath, absolutePath, True)

                ' Insert post information into the database
                Dim query As String = "INSERT INTO manage_post (admin_id, post, media_path, date_upload) VALUES (@admin_id, @post, @media_path, @date_upload)"
                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@admin_id", GlobalVariables.CurrentAdminID) ' Use the stored admin ID
                    command.Parameters.AddWithValue("@post", TBoxContent.Text)
                    command.Parameters.AddWithValue("@media_path", mediaDestinationPath) ' Store the relative path
                    command.Parameters.AddWithValue("@date_upload", DateTime.Now)

                    command.ExecuteNonQuery()
                    MessageBox.Show("Post submitted successfully!")
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As IOException
                MessageBox.Show("File error: " & ex.Message)
            Finally
                connection.Close()
            End Try
        End Using
    End Sub


    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        TBoxContent.Clear()
        pbPreview.Image = Nothing

    End Sub

    Private Sub BtnHomePage_Click(sender As Object, e As EventArgs) Handles BtnHomePage.Click
        Me.Hide()
        HomePageForm.Show()

    End Sub

    Private Sub BtnManageRequest_Click(sender As Object, e As EventArgs) Handles BtnManageRequest.Click
        Me.Hide()
        ManageRequestForm.Show()

    End Sub

    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click

        Dim result As DialogResult = MessageBox.Show("Are you sure you want to Logout?", "Log Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            LoginForm.Show()
        End If

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        ' Display or replace Label6 with the admin username
        Dim connectionString As String = "Server=localhost;Database=bss;User ID=root;"
        Using connection As New MySqlConnection(connectionString)
            Try
                connection.Open()

                ' Query to retrieve admin username based on admin ID
                Dim query As String = "SELECT admin_user FROM admin_credentials WHERE admin_id = @admin_id"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@admin_id", GlobalVariables.CurrentAdminID) ' Use the stored admin ID

                    Dim adminUsername As Object = command.ExecuteScalar()

                    If adminUsername IsNot Nothing Then
                        Label6.Text = "Admin: " & adminUsername.ToString()
                    End If
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Finally
                connection.Close()
            End Try
        End Using
    End Sub

    Private Sub report_btn_Click(sender As Object, e As EventArgs) Handles report_btn.Click
        Me.Hide()
        Form6.Show()

    End Sub

    ' Load posts into DataGridView
    Private Sub CreatePostForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadPostsIntoDataGridView()
    End Sub

    Private Sub LoadPostsIntoDataGridView()
        Dim connectionString As String = "Server=localhost;Database=bss;User ID=root;"
        Using connection As New MySqlConnection(connectionString)
            Try
                connection.Open()

                Dim query As String = "SELECT post_id, post FROM manage_post"
                Dim adapter As New MySqlDataAdapter(query, connection)
                Dim dataTable As New DataTable()
                adapter.Fill(dataTable)

                deletedata.DataSource = dataTable
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Finally
                connection.Close()
            End Try
        End Using
    End Sub

    ' Delete selected post from DataGridView and database
    Private Sub delete_Click(sender As Object, e As EventArgs) Handles delete.Click
        If deletedata.SelectedRows.Count > 0 Then
            Dim postId As Integer = Convert.ToInt32(deletedata.SelectedRows(0).Cells("post_id").Value)

            Dim connectionString As String = "Server=localhost;Database=bss;User ID=root;"
            Using connection As New MySqlConnection(connectionString)
                Try
                    connection.Open()

                    Dim query As String = "DELETE FROM manage_post WHERE post_id = @post_id"
                    Using command As New MySqlCommand(query, connection)
                        command.Parameters.AddWithValue("@post_id", postId)
                        command.ExecuteNonQuery()

                        MessageBox.Show("Post deleted successfully!")
                    End Using

                    ' Refresh the DataGridView
                    LoadPostsIntoDataGridView()
                Catch ex As MySqlException
                    MessageBox.Show("Database error: " & ex.Message)
                Finally
                    connection.Close()
                End Try
            End Using
        Else
            MessageBox.Show("Please select a post to delete.")
        End If
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs)

    End Sub
End Class
