﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient
Imports System.Windows.Forms.DataVisualization.Charting


Public Class Form6
    Dim isSidebarExpanded As Boolean = False ' To track the current state of the sidebar
    Dim sidebarExpandedWidth As Integer = 238 ' Width of the expanded sidebar
    Dim sidebarCollapsedWidth As Integer = 57 ' Width of the collapsed sidebar
    Dim transitionStep As Integer = 10 ' Width change step for each timer tick

    Private Sub Close_Click(sender As Object, e As EventArgs) Handles Close.Click
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub menu_Click(sender As Object, e As EventArgs) Handles menu.Click
        ToggleSidebar() ' Call the method to toggle the sidebar width
    End Sub

    Private Sub ToggleSidebar()
        ' Toggle the state of the sidebar
        isSidebarExpanded = Not isSidebarExpanded

        ' Start the timer for the transition effect
        SidebarTransitionTimer.Start()
    End Sub

    Private Sub SidebarTransitionTimer_Tick(sender As Object, e As EventArgs) Handles SidebarTransitionTimer.Tick
        If isSidebarExpanded Then
            ' Expand the sidebar
            If sidebar.Width < sidebarExpandedWidth Then
                sidebar.Width += transitionStep
            Else
                ' Stop the timer when the sidebar reaches its expanded width
                SidebarTransitionTimer.Stop()
            End If
        Else
            ' Collapse the sidebar
            If sidebar.Width > sidebarCollapsedWidth Then
                sidebar.Width -= transitionStep
            Else
                ' Stop the timer when the sidebar reaches its collapsed width
                SidebarTransitionTimer.Stop()
            End If
        End If
    End Sub

    Private Sub sidebar_Paint(sender As Object, e As PaintEventArgs)
        ' You can add any custom drawing or painting code for the sidebar here
    End Sub

    Private Sub BtnCreatePost_Click(sender As Object, e As EventArgs) Handles BtnCreatePost.Click
        Me.Hide()
        CreatePostForm.Show()

    End Sub

    Private Sub BtnManageRequest_Click(sender As Object, e As EventArgs) Handles BtnManageRequest.Click
        Me.Hide()
        ManageRequestForm.Show()

    End Sub

    Private Sub BtnHomePage_Click(sender As Object, e As EventArgs) Handles BtnHomePage.Click
        Me.Hide()
        HomePageForm.Show()

    End Sub

    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click

        Dim result As DialogResult = MessageBox.Show("Are you sure you want to Logout?", "Log Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            LoginForm.Show()
        End If

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Load reports into the ListBox when the form loads
        LoadReports()
        LoadUserCredentials()
        ' Calculate and display the total number of students
        CalculateTotalStudents()
    End Sub

    Private Sub LoadReports()
        ' Database connection details
        Dim connectionString As String = "Server=localhost;Database=bss;Uid=root;"
        Dim connection As New MySqlConnection(connectionString)

        Try
            ' Open the connection
            connection.Open()

            ' SQL select query to fetch data from report table
            Dim query As String = "SELECT user_id, username, report_content FROM report"

            ' Create a command
            Dim command As New MySqlCommand(query, connection)

            ' Execute the command and read the data
            Dim reader As MySqlDataReader = command.ExecuteReader()

            ' Clear the ListBox before adding new items
            ListBox1.Items.Clear()

            ' Loop through the data and add it to the ListBox
            While reader.Read()
                Dim userId As Integer = reader("user_id")
                Dim username As String = reader("username").ToString()
                Dim reportContent As String = reader("report_content").ToString()

                ' Format the data as you like
                Dim displayText As String = String.Format("User ID: {0}, Username: {1}, Report: {2}", userId, username, reportContent)

                ' Add the formatted data to the ListBox
                ListBox1.Items.Add(displayText)
            End While

            ' Close the reader
            reader.Close()

        Catch ex As MySqlException
            MessageBox.Show("Error: " & ex.Message)
        Finally
            ' Close the connection
            connection.Close()
        End Try
    End Sub
    Private Sub LoadUserCredentials()
        ' Database connection details
        Dim connectionString As String = "Server=localhost;Database=bss;Uid=root;"
        Dim connection As New MySqlConnection(connectionString)

        Try
            ' Open the connection
            connection.Open()

            ' SQL select query to fetch data from user credentials table
            Dim query As String = "SELECT student_id, username, email FROM user_credentials"

            ' Create a command
            Dim command As New MySqlCommand(query, connection)

            ' Execute the command and read the data
            Dim reader As MySqlDataReader = command.ExecuteReader()

            ' Clear the ListBox before adding new items
            ListBox2.Items.Clear()

            ' Loop through the data and add it to the ListBox
            While reader.Read()
                Dim studentId As String = reader("student_id").ToString()
                Dim username As String = reader("username").ToString()
                Dim email As String = reader("email").ToString()

                ' Format the data as you like
                Dim displayText As String = String.Format("Student ID: {0}, Username: {1}, Email: {2}", studentId, username, email)

                ' Add the formatted data to ListBox2
                ListBox2.Items.Add(displayText)
            End While

            ' Close the reader
            reader.Close()

        Catch ex As MySqlException
            MessageBox.Show("Error: " & ex.Message)
        Finally
            ' Close the connection
            connection.Close()
        End Try
    End Sub

    Private Sub CalculateTotalStudents()
        ' Database connection details
        Dim connectionString As String = "Server=localhost;Database=bss;Uid=root;"
        Dim connection As New MySqlConnection(connectionString)

        Try
            ' Open the connection
            connection.Open()

            ' SQL select query to calculate the total number of students based on user ID
            Dim query As String = "SELECT COUNT(*) FROM user_credentials"

            ' Create a command
            Dim command As New MySqlCommand(query, connection)

            ' Execute the command to get the total count
            Dim totalStudents As Integer = Convert.ToInt32(command.ExecuteScalar())

            ' Display the total count in TextBox1
            display.Text = totalStudents & " Students"

        Catch ex As MySqlException
            MessageBox.Show("Error: " & ex.Message)
        Finally
            ' Close the connection
            connection.Close()
        End Try
    End Sub

    Private Sub LoginHistoryForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadLoginHistory()
    End Sub

    Private Sub LoadLoginHistory()
        Dim connectionString As String = "Server=localhost;Database=bss;Uid=root;"
        Dim query As String = "SELECT DATE(login_time) AS login_date, COUNT(*) AS login_count FROM login_history GROUP BY DATE(login_time) ORDER BY login_date;"

        Using connection As New MySqlConnection(connectionString)
            Dim command As New MySqlCommand(query, connection)

            Try
                connection.Open()
                Dim reader As MySqlDataReader = command.ExecuteReader()

                Dim loginDates As New List(Of String)()
                Dim loginCounts As New List(Of Integer)()

                While reader.Read()
                    loginDates.Add(reader("login_date").ToString())
                    loginCounts.Add(Convert.ToInt32(reader("login_count")))
                End While

                reader.Close()

                ' Set up the chart
                Chart1.Series.Clear()
                Chart1.Titles.Clear()

                Dim series As New Series("Logins")
                series.ChartType = SeriesChartType.Column

                Chart1.Series.Add(series)

                For i As Integer = 0 To loginDates.Count - 1
                    series.Points.AddXY(loginDates(i), loginCounts(i))
                Next

                Chart1.ChartAreas(0).AxisX.Title = "Date"
                Chart1.ChartAreas(0).AxisY.Title = "Number of Logins"
                Chart1.Titles.Add("User Login History")
            Catch ex As MySqlException
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub
End Class