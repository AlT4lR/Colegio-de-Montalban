<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'bss';

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.html");
    exit();
}

// Get user ID
$user_id = $_SESSION['user_id'];

// Fetch user information from the database
$query = "SELECT * FROM user_credentials WHERE user_id = '$user_id'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found.";
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../styles/dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

    <style>
        .floating-window {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            border: 1px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            display: none;
        }

        .close-button {
            position: absolute;
            top: 5px;
            right: 5px;
            cursor: pointer;
        }
    </style>
</head>

<body class="bg-gray-100">
<nav class="bg-green-500 py-4">
    <div class="container mx-auto flex justify-between items-center">
        <div class="flex items-center space-x-4">
            <img src="../styles/img/366165555_109528598905526_3016794916943036402_n.jpg" alt="Colegio de Montalban" class="h-10 w-10 rounded-full">
            <h1 class="text-white text-2xl font-bold">CdM Bulletin</h1>
        </div>
        <ul class="flex space-x-6 text-white">
            <li>
                <a href="dashboard.html" data-page="manage_post.php" class="hover:text-gray-200 flex items-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
                    </svg>
                    <span>ANNOUNCEMENT</span>
                </a>
            </li>
            <li>
                <a href="./post.html" class="hover:text-gray-200 flex items-center space-x-1">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M7.5 7.5h-.75A2.25 2.25 0 0 0 4.5 9.75v7.5a2.25 2.25 0 0 0 2.25 2.25h7.5a2.25 2.25 0 0 0 2.25-2.25v-7.5a2.25 2.25 0 0 0-2.25-2.25h-.75m0-3-3-3m0 0-3 3m3-3v11.25m6-2.25h.75a2.25 2.25 0 0 1 2.25 2.25v7.5a2.25 2.25 0 0 1-2.25 2.25h-7.5a2.25 2.25 0 0 1-2.25-2.25v-.75" />
                    </svg>
                    <span>POST</span>
                </a>
            </li>
            <li>
                <a href="./calendar.html" class="hover:text-gray-200 flex items-center space-x-1">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0v-7.5A2.25 2.25 0 0 1 5.25 9h13.5A2.25 2.25 0 0 1 21 11.25v7.5" />
                    </svg>
                    <span>CALENDAR</span>
                </a>
            </li>
            <li>
                <a href="./profile.php" class="hover:text-gray-200 flex items-center space-x-1">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17.982 18.725A7.488 7.488 0 0 0 12 15.75a7.488 7.488 0 0 0-5.982 2.975m11.963 0a9 9 0 1 0-11.963 0m11.963 0A8.966 8.966 0 0 1 12 21a8.966 8.966 0 0 1-5.982-2.275M15 9.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                    </svg>
                    <span>PROFILE</span>
                </a>
            </li>
            <li>
                <a href="./about.html" class="hover:text-gray-200 flex items-center space-x-1">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 15.75h.008v.008H12v-.008Zm0-6.75h.008v5.25H12v-5.25Zm0-4.5h.008v2.25H12V4.5Zm0 0a7.5 7.5 0 1 0 7.5 7.5A7.5 7.5 0 0 0 12 4.5Z" />
                    </svg>
                    <span>ABOUT</span>
                </a>
            </li>
        </ul>
    </div>
</nav>
<br>


    <div class="container mx-auto mt-6">
        <div class="flex justify-center mb-4">
            <div class="w-full max-w-lg bg-white p-6 rounded-lg shadow-lg">
                <p class="text-gray-700"><strong>Student ID:</strong> <?php echo $user['student_id']; ?></p>
                <p class="text-gray-700"><strong>Username:</strong> <?php echo $user['username']; ?></p>
                <p class="text-gray-700"><strong>Email:</strong> <?php echo $user['email']; ?></p>
            </div>
        </div>

        <!-- Feedback Form -->
        <div class="flex justify-center mb-4">
            <div class="w-full max-w-lg bg-white p-6 rounded-lg shadow-lg">
                <h2 class="text-2xl font-bold mb-4">Submit Feedback</h2>
                <form id="feedbackForm" class="space-y-4">
                    <div>
                        <label for="feedbackContent" class="block text-gray-700">Feedback:</label>
                        <textarea id="feedbackContent" name="feedbackContent" required
                            class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500"></textarea>
                    </div>
                    <div class="text-center">
                        <input type="submit" value="Submit Feedback"
                            class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-700 cursor-pointer">
                    </div>
                </form>
            </div>
        </div>

        <div id="notification" class="hidden p-4 mb-4 text-sm rounded-lg text-center"></div>

        <div class="flex justify-center space-x-4">
            <button onclick="confirmLogout()" class="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 15 3 9m0 0 6-6M3 9h12a6 6 0 0 1 0 12h-3" />
                </svg>
                Logout
            </button>
            <button onclick="openChangePasswordFloatingWindow()" class="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M15.75 5.25a3 3 0 0 1 3 3m3 0a6 6 0 0 1-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1 1 21.75 8.25Z" />
                </svg>
                Change Password
            </button>
        </div>
    </div>

    <div id="pContent"></div>

    <div id="changePasswordFloatingWindow" class="floating-window bg-white p-6 rounded-lg shadow-lg">
        <span class="close-button text-red-500 text-xl font-bold" onclick="closeChangePasswordFloatingWindow()">&times;</span>
        <h2 class="text-2xl font-bold mb-4">Change Password</h2>
        <form id="changePasswordForm" class="space-y-4">
            <div>
                <label for="currentPassword" class="block text-gray-700">Current Password:</label>
                <input type="password" id="currentPassword" name="currentPassword" required
                    class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
            </div>
            <div>
                <label for="newPassword" class="block text-gray-700">New Password:</label>
                <input type="password" id="newPassword" name="newPassword" required
                    class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
            </div>
            <div class="text-center">
                <input type="submit" value="Change Password"
                    class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-700 cursor-pointer">
            </div>
        </form>
    </div>

    <script>
        function confirmLogout() {
            var confirmation = confirm("Are you sure you want to logout?");
            if (confirmation) {
                axios.get('../backend/logout.php')
                    .then(function(response) {
                        displayNotification(response.data.message, 'green');
                        setTimeout(function() {
                            window.location.href = "../index.html";
                        }, 2000);
                    })
                    .catch(function(error) {
                        displayNotification('Error logging out. Please try again.', 'red');
                    });
            }
        }

        document.getElementById('changePasswordForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(this);

            axios.post('../backend/change_pass.php', formData)
                .then(function(response) {
                    const { status, message } = response.data;
                    displayNotification(message, status === 'success' ? 'green' : 'red');
                    if (status === 'success') {
                        setTimeout(function() {
                            closeChangePasswordFloatingWindow();
                        }, 2000);
                    }
                })
                .catch(function(error) {
                    displayNotification('Error changing password. Please try again.', 'red');
                });
        });

        function openChangePasswordFloatingWindow() {
            var changePasswordFloatingWindow = document.getElementById("changePasswordFloatingWindow");
            changePasswordFloatingWindow.style.display = "block";
        }

        function closeChangePasswordFloatingWindow() {
            var changePasswordFloatingWindow = document.getElementById("changePasswordFloatingWindow");
            changePasswordFloatingWindow.style.display = "none";
        }

        function displayNotification(message, color) {
            const notification = document.getElementById('notification');
            notification.className = `p-4 mb-4 text-sm text-${color}-700 bg-${color}-100 rounded-lg text-center`;
            notification.innerText = message;
            notification.classList.remove('hidden');
        }

        document.getElementById('feedbackForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(this);
            formData.append('userId', <?php echo json_encode($user['user_id']); ?>);
            formData.append('username', <?php echo json_encode($user['username']); ?>);

            axios.post('../backend/submit_feedback.php', formData)
                .then(function(response) {
                    const { status, message } = response.data;
                    displayNotification(message, status === 'success' ? 'green' : 'red');
                    if (status === 'success') {
                        setTimeout(function() {
                            document.getElementById('feedbackForm').reset();
                        }, 2000);
                    }
                })
                .catch(function(error) {
                    displayNotification('Error submitting feedback. Please try again.', 'red');
                });
        });
    </script>
</body>

</html>
