<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bss";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT p.post_id, p.admin_id, p.post, p.media_path, p.date_upload, a.admin_user AS admin_username 
        FROM manage_post p 
        JOIN admin_credentials a ON p.admin_id = a.admin_id 
        ORDER BY p.post_id DESC";

$result = $conn->query($sql);

$posts = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $post_id = $row['post_id'];
        $sql_comments = "SELECT c.user_id, c.comment_content, c.comment_date, u.username AS user_username 
                         FROM manage_comments c 
                         JOIN user_credentials u ON c.user_id = u.user_id 
                         WHERE c.post_id = '" . $post_id . "'";
        $result_comments = $conn->query($sql_comments);

        $post = $row;
        $post['comments'] = array();

        if ($result_comments->num_rows > 0) {
            while ($comment_row = $result_comments->fetch_assoc()) {
                $post['comments'][] = $comment_row;
            }
        }

        $posts[] = $post;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Posts and Comments</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .comment-toggle {
            cursor: pointer;
        }

        .comment-toggle:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body class="bg-gray-100 p-4">

    <div class="max-w-3xl mx-auto" id="posts-container">
        <!-- Posts will be injected here by JS -->
    </div>

    <script>
        const posts = <?php echo json_encode($posts, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
    </script>
    <!--<script src="../backend/js/mPost.js"></script> no longer needed, duplicated-->
    <script>
        $(document).ready(function () {
            const postsContainer = $('#posts-container');

            if (posts.length === 0) {
                postsContainer.append('<p class="text-gray-600">No posts found</p>');
            } else {
                posts.forEach(post => {
                    const postElement = $(`
    <div class="bg-white shadow-lg rounded-lg mb-4 border border-gray-300 p-2">
        <div class="p-4">
            <p class="text-sm text-gray-500">Posted by ${post.admin_username} on ${post.date_upload}</p>
            <p class="text-lg font-semibold mt-2">${post.post.replace(/\n/g, '<br>')}</p>
            <div class="media-container mt-2"></div>
            <div class="flex items-center mt-4">
                <button class="text-sm text-gray-500 mr-4 hover:text-blue-500 upvote-btn" data-post-id="${post.post_id}">
                    Upvote (<span class="upvote-count-${post.post_id}">Loading...</span>)
                </button>
                <button class="text-sm text-gray-500 mr-4 hover:text-blue-500 comment-toggle" data-comments-id="${post.post_id}">
                    Comments (<span class="comment-count-${post.post_id}">${post.comments.length}</span>)
                </button>
            </div>
        </div>
        <div id="comments_${post.post_id}" class="p-4 border-t border-gray-300 hidden">
            <div class="comments-list"></div>
            <div class="mt-4">
                <form class="comment-form flex" data-post-id="${post.post_id}">
                    <input type="text" name="comment_content" placeholder="Comment something..." class="flex-grow border rounded-l px-3 py-2" required>
                    <button type="submit" class="bg-blue-500 text-white px-3 py-2 rounded-r">Send</button>
                </form>
            </div>
        </div>
    </div>
`);

                    // fetch files if available
                    if (post.media_path) {
                        const mediaPath = `../uploads/${post.media_path}`;
                        const fileExtension = mediaPath.split('.').pop().toLowerCase();

                        if (['jpg', 'jpeg', 'png'].includes(fileExtension)) {
                            postElement.find('.media-container').html(`<img src="${mediaPath}" alt="Cant Retrieve Media" class="mt-2 mx-auto max-w-full">`);
                        } else if (['mp4', 'avi'].includes(fileExtension)) {
                            postElement.find('.media-container').html(`<video controls class="mt-2 mx-auto max-w-full"><source src="${mediaPath}" type="video/${fileExtension}">Your browser does not support the video tag.</video>`);
                        } else {
                            postElement.find('.media-container').text(`Unsupported file format: ${fileExtension}`);
                        }
                    }

                    // get comments
                    const commentsContainer = postElement.find('.comments-list');
                    if (post.comments.length === 0) {
                        commentsContainer.append('<p class="no-comments text-gray-500">No comments found</p>');
                    } else {
                        post.comments.forEach(comment => {
                            commentsContainer.append(`
                            <div class="bg-gray-100 rounded-lg p-3 mb-3">
                                <p class="text-sm text-gray-500">Commented by ${comment.user_username} on ${comment.comment_date}</p>
                                <p class="mt-1">${comment.comment_content}</p>
                            </div>
                        `);
                        });
                    }

                    postsContainer.append(postElement);
                });
            }

            $('.upvote-btn').click(function () {
                const postId = $(this).data('post-id');
                const btn = $(this);
                $.ajax({
                    type: 'POST',
                    url: '../backend/upvote.php',
                    data: { post_id: postId, user_id: <?php echo $_SESSION['user_id']; ?> },
                    success: function (response) {
                        const data = JSON.parse(response);
                        if (data.success) {
                            const upvoteCount = data.upvotes;
                            $('.upvote-count-' + postId).text(upvoteCount);
                            btn.prop('disabled', true);
                        } else {
                            alert(data.message);
                        }
                    }
                });
            });

            $('.comment-toggle').click(function () {
                const postId = $(this).data('comments-id');
                $('#comments_' + postId).toggleClass('hidden');
            });

            // AJAX form submission for comments
            $(document).on('submit', '.comment-form', function (event) {
                event.preventDefault();
                const form = $(this);
                const postId = form.data('post-id');
                const commentContent = form.find('input[name="comment_content"]').val();

                $.ajax({
                    type: 'POST',
                    url: '../backend/submit_comment.php',
                    data: { post_id: postId, comment_content: commentContent },
                    success: function (response) {
                        const data = JSON.parse(response);
                        if (data.success) {
                            const newComment = `
                            <div class="bg-gray-50 rounded-lg p-3 mb-3">
                                <p class="text-sm text-gray-500">Commented by ${data.user_username} on ${data.comment_date}</p>
                                <p class="mt-1">${data.comment_content}</p>
                            </div>
                        `;
                            const commentsList = $('#comments_' + postId + ' .comments-list');
                            commentsList.append(newComment);
                            form[0].reset();
                            const commentCountSpan = $(`.comment-toggle[data-comments-id="${postId}"] .comment-count-${postId}`);
                            commentCountSpan.text(parseInt(commentCountSpan.text()) + 1);

                            commentsList.find('.no-comments').remove();
                        } else {
                            alert(data.message);
                        }
                    }
                });
            });
        });
    </script>
    <script src="../backend/js/getUpvote.js"></script>

</body>

</html>
