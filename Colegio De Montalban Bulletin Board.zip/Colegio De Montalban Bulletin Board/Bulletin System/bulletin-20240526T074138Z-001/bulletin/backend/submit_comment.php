<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.html");
    exit();
}

$user = $_SESSION['user_id'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bss";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['comment_content'], $_POST['post_id'])){
        $comment_content = $_POST['comment_content'];
        $post_id = $_POST['post_id'];
        $sql = "INSERT INTO manage_comments (post_id, user_id, comment_content, comment_date) VALUES ('$post_id', '$user', '$comment_content', NOW())";
        if ($conn->query($sql) === TRUE) {
            $response = [
                'success' => true,
                'user_id' => $user,
                'comment_content' => $comment_content,
                'comment_date' => date("Y-m-d H:i:s")
            ];
            echo json_encode($response);
        } else {
            echo json_encode(['success' => false, 'message' => "Error: " . $sql . "<br>" . $conn->error]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => "Both comment content and post ID must be provided."]);
    }
}

$conn->close();
?>
