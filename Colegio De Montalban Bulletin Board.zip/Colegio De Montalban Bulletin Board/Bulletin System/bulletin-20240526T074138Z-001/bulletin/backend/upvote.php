<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postId = $_POST['post_id'];
    $userId = $_POST['user_id'];

    $upvotesFile = './json/upvotes.json';
    $upvotes = file_exists($upvotesFile) ? json_decode(file_get_contents($upvotesFile), true) : array();

    if (isset($upvotes[$postId]) && in_array($userId, $upvotes[$postId]['upvoted_users'])) {
        echo json_encode(['success' => false, 'message' => 'You have already upvoted this post.']);
        exit();
    }

    if (!isset($upvotes[$postId])) {
        $upvotes[$postId] = ['upvotes' => 1, 'upvoted_users' => [$userId]];
    } else {
        $upvotes[$postId]['upvotes']++;
        $upvotes[$postId]['upvoted_users'][] = $userId;
    }

    file_put_contents($upvotesFile, json_encode($upvotes));

    echo json_encode(['success' => true, 'upvotes' => $upvotes[$postId]['upvotes']]);
} else {
    http_response_code(405);
    echo 'Method Not Allowed';
}
?>
