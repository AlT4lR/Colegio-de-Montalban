<?php
session_start();

$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'bss';

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    $response = array("status" => "error", "message" => "Connection failed: " . $conn->connect_error);
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $currentPassword = $_POST['currentPassword'];
    $newPassword = $_POST['newPassword'];

    $user = $_SESSION['user_id'];

    $sql = "SELECT password FROM user_credentials WHERE user_id = '$user'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $currentPasswordDB = $row['password'];

        if ($currentPassword != $currentPasswordDB) {
            $response = array("status" => "error", "message" => "Current password is incorrect!");
            header('Content-Type: application/json');
            echo json_encode($response);
            exit();
        }

        $sqlUpdate = "UPDATE user_credentials SET password = '$newPassword' WHERE user_id = '$user'";
        if ($conn->query($sqlUpdate) === TRUE) {
            $response = array("status" => "success", "message" => "Password changed successfully!");
            header('Content-Type: application/json');
            echo json_encode($response);
            exit();
        } else {
            $response = array("status" => "error", "message" => "Error updating record: " . $conn->error);
            header('Content-Type: application/json');
            echo json_encode($response);
            exit();
        }
    } else {
        $response = array("status" => "error", "message" => "No user found.");
        header('Content-Type: application/json');
        echo json_encode($response);
        exit();
    }
}

$conn->close();
?>
