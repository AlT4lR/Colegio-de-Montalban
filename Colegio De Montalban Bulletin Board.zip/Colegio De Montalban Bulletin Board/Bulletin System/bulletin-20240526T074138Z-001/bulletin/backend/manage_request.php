<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "bss";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
}

$user_id = $_SESSION['user_id'];

$query = "SELECT status FROM manage_request WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($status);

$response = ["status" => "error", "message" => "Request status not found"];

if ($stmt->fetch()) {
    $response = ["status" => $status];
}

echo json_encode($response);
$stmt->close();
$conn->close();
?>
