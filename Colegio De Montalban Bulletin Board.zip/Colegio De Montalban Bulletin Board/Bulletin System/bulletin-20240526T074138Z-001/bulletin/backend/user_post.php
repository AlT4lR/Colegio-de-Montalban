<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$database = "bss";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['user_id'])) {
        $response['message'] = 'User not logged in.';
        echo json_encode($response);
        exit();
    }

    $userid = $_SESSION['user_id'];

    // validate if user had an approved request
    $requestQuery = "SELECT status FROM manage_request WHERE user_id = ? AND status = 'approved'";
    $requestStmt = $conn->prepare($requestQuery);
    if ($requestStmt === false) {
        $response['message'] = 'Error preparing statement: ' . $conn->error;
        echo json_encode($response);
        exit();
    }
    $requestStmt->bind_param("i", $userid);
    $requestStmt->execute();
    $requestStmt->store_result();

    if ($requestStmt->num_rows == 0) {
        $response['message'] = 'You need to have an approved request to post.';
        echo json_encode($response);
        exit();
    }
    $requestStmt->close();

    // upload post
    $caption = $_POST['caption'];
    $date_upload = date("Y-m-d H:i:s");

    // directory of files if have one
    $target_dir = "C:\\xampp\\htdocs\\bulletin\\uploads\\uploads\\";
    $mediaFileName = basename($_FILES["media"]["name"]);
    $target_file = $target_dir . $mediaFileName;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // check if file is an image or video
    $check = getimagesize($_FILES["media"]["tmp_name"]);
    if ($check !== false || strpos(mime_content_type($_FILES["media"]["tmp_name"]), "video") === 0) {
        $uploadOk = 1;
    } else {
        $response['message'] = 'File is not an image or video.';
        $uploadOk = 0;
    }

    // heck if already exists in folder uploads
    if (file_exists($target_file)) {
        $response['message'] = 'Sorry, file already exists.';
        $uploadOk = 0;
    }

    // i dont have to full my system for useless files with large mb so theres a limit
    if ($_FILES["media"]["size"] > 5000000) {
        $response['message'] = 'Sorry, your file is too large.';
        $uploadOk = 0;
    }

    // available file formats
    $allowedFormats = ["jpg", "jpeg", "png", "webp", "mp4", "avi"];
    if (!in_array($imageFileType, $allowedFormats)) {
        $response['message'] = 'Sorry, only JPG, JPEG, PNG, WEBP, MP4 & AVI files are allowed.';
        $uploadOk = 0;
    }

    if ($uploadOk == 0) {
        $response['message'] = 'Sorry, your file was not uploaded.';
    } else {
        if (move_uploaded_file($_FILES["media"]["tmp_name"], $target_file)) {
            // Insert post information into the database
            $relative_path = "uploads\\" . $mediaFileName;
            $query = "INSERT INTO manage_post (user_id, post, media_path, date_upload) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            if ($stmt === false) {
                $response['message'] = 'Error preparing statement: ' . $conn->error;
            } else {
                $stmt->bind_param("isss", $userid, $caption, $relative_path, $date_upload);
                if ($stmt->execute()) {
                    // Reset the user's request status
                    $updateQuery = "UPDATE manage_request SET status = 'posted' WHERE user_id = ? AND status = 'approved'";
                    $updateStmt = $conn->prepare($updateQuery);
                    if ($updateStmt) {
                        $updateStmt->bind_param("i", $userid);
                        $updateStmt->execute();
                        $updateStmt->close();
                    }

                    $response['success'] = true;
                    $response['message'] = 'Post submitted successfully! You need to request approval for further posts.';
                } else {
                    $response['message'] = 'Error executing statement: ' . $stmt->error;
                }
                $stmt->close();
            }
        } else {
            $response['message'] = 'Sorry, there was an error uploading your file.';
        }
    }
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
