<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$user = "root";
$password = "";
$database = "bss";

$conn = new mysqli($servername, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = ['success' => false, 'message' => 'Invalid username or password'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $check_query = "SELECT * FROM user_credentials WHERE student_id = ? AND username = ? AND password = ?";
    $stmt = $conn->prepare($check_query);
    
    $stmt->bind_param("sss", $student_id, $username, $password);
    
    $stmt->execute();
    
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['user_id'];

        // Insert login record into user_login_history table
        $insertQuery = "INSERT INTO login_history (user_id, login_time) VALUES (?, NOW())";
        $insertStmt = $conn->prepare($insertQuery);
        $insertStmt->bind_param("i", $user['user_id']);
        $insertStmt->execute();
        $insertStmt->close();

        $response['success'] = true;
        $response['message'] = 'Successfully Logged In!';
    }
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
