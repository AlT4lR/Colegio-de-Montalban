<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'bss';

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// check if user is not logged in, return an error, gawa ni gpt
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_POST['username'];
$feedback_content = $conn->real_escape_string($_POST['feedbackContent']);

$query = "INSERT INTO report (user_id, username, report_content) VALUES ('$user_id', '$username', '$feedback_content')";

if ($conn->query($query) === TRUE) {
    echo json_encode(['status' => 'success', 'message' => 'Feedback submitted successfully.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error submitting feedback: ' . $conn->error]);
}

$conn->close();
?>
