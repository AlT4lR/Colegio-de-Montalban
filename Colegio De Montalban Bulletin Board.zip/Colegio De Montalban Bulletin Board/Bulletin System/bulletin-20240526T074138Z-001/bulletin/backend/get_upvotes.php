<?php
$postId = $_GET['post_id'];

$upvotesData = file_get_contents('./json/upvotes.json');
$upvotes = json_decode($upvotesData, true);

if (isset($upvotes[$postId])) {
    echo $upvotes[$postId]['upvotes'];
} else {
    echo '0';
}
?>
