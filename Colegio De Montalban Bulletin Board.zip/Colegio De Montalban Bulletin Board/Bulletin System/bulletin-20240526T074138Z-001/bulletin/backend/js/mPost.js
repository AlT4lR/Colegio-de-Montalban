/* Just  ignore the errors, it's because js doesn't recognize php syntax.
   So, that's it. Ignore,
*/
function initializePage() {
    $('.upvote-btn').each(function () {
        var postId = $(this).data('post-id');
        var upvoteCountSpan = $('.upvote-count-' + postId);
        $.ajax({
            type: 'GET',
            url: '../backend/get_upvotes.php',
            data: { post_id: postId },
            success: function (response) {
                upvoteCountSpan.text(response);
            }
        });
    });

    $('.comment-toggle').click(function () {
        var commentsId = $(this).data('comments-id');
        $('#comments_' + commentsId).toggleClass('hidden');
    });

    // Function to fetch comments and update
    function fetchAndUpdateComments(postId) {
        var commentsDiv = $('#comments_' + postId + ' .comments-list');
        $.ajax({
            type: 'GET',
            url: '../backend/get_comments.php',
            data: { post_id: postId },
            success: function (response) {
                var comments = JSON.parse(response);
                commentsDiv.empty();
                if (comments.length > 0) {
                    comments.forEach(function (comment) {
                        var commentHtml = '<div class="bg-gray-50 rounded-lg p-3 mb-3">' +
                            '<p class="text-sm text-gray-500">Commented by ' + comment.user_id + ' on ' + comment.comment_date + '</p>' +
                            '<p class="mt-1">' + comment.comment_content + '</p>' +
                            '</div>';
                        commentsDiv.append(commentHtml);
                    });
                }
            }
        });
    }

    // Event listener for comment toggle button
    $('.comment-toggle').click(function () {
        var postId = $(this).data('comments-id');
        var commentsDiv = $('#comments_' + postId + ' .comments-list');
        commentsDiv.html('<p class="text-gray-500">Loading comments...</p>');
        fetchAndUpdateComments(postId);
        setInterval(function () {
            fetchAndUpdateComments(postId); // Fetch comments every 5 seconds
        }, 5000);
    });

    $('.comment-form').submit(function (event) {
        event.preventDefault();
        var postId = $(this).data('post-id');
        var commentInput = $(this).find('input[name="comment_content"]');
        var commentContent = commentInput.val().trim();
        if (commentContent !== '') {
            $.ajax({
                type: 'POST',
                url: '../backend/submit_comment.php',
                data: { post_id: postId, comment_content: commentContent },
                success: function (response) {
                    // Handle success
                }
            });
            commentInput.val('');
        }
    });
}

$(document).ready(function () {
    initializePage();
});
