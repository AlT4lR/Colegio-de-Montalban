function getUpvoteCount(postId) {
    return new Promise((resolve, reject) => {
        fetch(`../backend/json/upvotes.json`)
            .then(response => response.json())
            .then(data => {
                if (data[postId]) {
                    resolve(data[postId]['upvotes']);
                } else {
                    resolve(0);
                }
            })
            .catch(error => reject(error));
    });
}

function updateUpvoteCounts() {
    document.querySelectorAll('.upvote-btn').forEach(button => {
        const postId = button.dataset.postId;
        const upvoteCountElement = document.querySelector(`.upvote-count-${postId}`);

        getUpvoteCount(postId)
            .then(count => {
                upvoteCountElement.textContent = count;
            })
            .catch(error => {
                console.error('Error fetching upvote count:', error);
                upvoteCountElement.textContent = 'Error';
            });
    });
}

updateUpvoteCounts();
setInterval(updateUpvoteCounts, 5000);
