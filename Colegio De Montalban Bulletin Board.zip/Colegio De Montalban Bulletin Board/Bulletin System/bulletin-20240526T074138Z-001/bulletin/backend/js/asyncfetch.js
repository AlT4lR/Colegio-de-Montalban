function loadCalen(page) {
    console.log('Loading page:', page); 
    fetch(page)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.text();
        })
        .then(html => {
            document.getElementById('cContent').innerHTML = html;
            if (window.location.hash === '#post') {
                console.log('Hiding mCont as the window URL contains #post');
                document.getElementById('cCont').style.display = 'none';
            } else {
                console.log('mCont is not hidden as the window URL does not contain #post');
            }
        })
        .catch(error => {
            console.error('Error fetching content:', error);
        });
}



function loadProf(page) {
    console.log('Loading page:', page); 
    fetch(page)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.text();
        })
        .then(html => {
            document.getElementById('pContent').innerHTML = html;
            if (window.location.hash === '#post') {
                console.log('Hiding mCont as the window URL contains #post');
                document.getElementById('mCont').style.display = 'none';
            } else {
                console.log('mCont is not hidden as the window URL does not contain #post');
            }
        })
        .catch(error => {
            console.error('Error fetching content:', error);
        });
}

