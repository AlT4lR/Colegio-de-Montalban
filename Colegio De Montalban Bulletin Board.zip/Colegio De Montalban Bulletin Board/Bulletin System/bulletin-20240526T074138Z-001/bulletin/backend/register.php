<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$user = "root";
$password = "";
$database = "bss";

$conn = new mysqli($servername, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = ['success' => false, 'message' => 'Error registering'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['message'] = 'Invalid email format';
    } elseif (strlen($password) < 6) {
        $response['message'] = 'Password too weak';
    } else {
        $check_query = "SELECT * FROM user_credentials WHERE student_id = ? OR username = ? OR email = ?";
        $stmt = $conn->prepare($check_query);
        $stmt->bind_param("sss", $student_id, $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $response['message'] = 'User already exists';
        } else {
            $insert_query = "INSERT INTO user_credentials (student_id, username, email, password) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_query);
            $stmt->bind_param("ssss", $student_id, $username, $email, $password);
            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'Successfully Registered!';
            } else {
                $response['message'] = 'Error registering user';
            }
        }
    }
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
