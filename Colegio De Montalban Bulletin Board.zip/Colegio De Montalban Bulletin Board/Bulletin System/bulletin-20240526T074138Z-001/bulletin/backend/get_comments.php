<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bss";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET['post_id'])) {
        $post_id = $_GET['post_id'];
        $sql = "SELECT user_id, comment_content, comment_date FROM manage_comments WHERE post_id = '$post_id' ORDER BY comment_date ASC";
        $result = $conn->query($sql);

        $comments = array();
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $comments[] = $row;
            }
        }

        echo json_encode($comments);
    } else {
        echo json_encode(array('error' => 'Post ID is required'));
    }
} else {
    echo json_encode(array('error' => 'Invalid request method'));
}

$conn->close();
?>
