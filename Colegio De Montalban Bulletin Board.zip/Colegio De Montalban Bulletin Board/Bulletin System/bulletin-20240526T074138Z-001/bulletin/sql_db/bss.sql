-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2024 at 03:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bss`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_credentials`
--

CREATE TABLE `admin_credentials` (
  `admin_id` int(11) NOT NULL,
  `admin_user` varchar(10) NOT NULL,
  `admin_pass` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_credentials`
--

INSERT INTO `admin_credentials` (`admin_id`, `admin_user`, `admin_pass`) VALUES
(1, 'admin', 'admin'),
(2, 'root', 'root123');

-- --------------------------------------------------------

--
-- Table structure for table `calendar_event`
--

CREATE TABLE `calendar_event` (
  `admin_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `event_name` varchar(255) DEFAULT NULL,
  `event_start_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calendar_event`
--

INSERT INTO `calendar_event` (`admin_id`, `event_id`, `event_name`, `event_start_date`) VALUES
(1, 1, 'Mr. and Ms. CDM', '2024-05-17'),
(1, 4, 'Sports Fest Day 1', '2024-05-06'),
(1, 5, 'Sports Fest Day 2', '2024-05-07'),
(1, 6, 'Sports Fest Day 3', '2024-05-08'),
(1, 7, 'Sports Fest Day 4', '2024-05-09'),
(1, 8, 'Sports Fest Day 5', '2024-05-10'),
(1, 9, 'ICS Week Day 1', '2024-05-23'),
(1, 10, 'ICS Week Day 2', '2024-05-24'),
(1, 11, 'ICS Week Day 3', '2024-05-25'),
(1, 12, 'Last Day of Sem', '2024-06-01');

-- --------------------------------------------------------

--
-- Table structure for table `login_history`
--

CREATE TABLE `login_history` (
  `login_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `login_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_history`
--

INSERT INTO `login_history` (`login_id`, `user_id`, `login_time`) VALUES
(1, 1, '2024-05-23 00:54:05'),
(2, 36, '2024-05-23 01:04:55'),
(3, 2, '2024-05-22 02:25:22'),
(4, 1, '2024-05-24 19:49:21'),
(5, 1, '2024-05-24 21:14:05');

-- --------------------------------------------------------

--
-- Table structure for table `manage_comments`
--

CREATE TABLE `manage_comments` (
  `comment_id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment_content` text DEFAULT NULL,
  `comment_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `manage_comments`
--

INSERT INTO `manage_comments` (`comment_id`, `post_id`, `user_id`, `comment_content`, `comment_date`) VALUES
(19, 21, 1, 'review malala', '2024-05-19 05:26:21'),
(20, 20, 38, 'less go', '2024-05-20 03:15:04'),
(23, 20, 1, 'anu to?', '2024-05-24 13:00:10');

-- --------------------------------------------------------

--
-- Table structure for table `manage_post`
--

CREATE TABLE `manage_post` (
  `post_id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `post` text NOT NULL,
  `media_path` varchar(255) DEFAULT NULL,
  `date_upload` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `manage_post`
--

INSERT INTO `manage_post` (`post_id`, `admin_id`, `user_id`, `post`, `media_path`, `date_upload`) VALUES
(20, 1, 0, 'Are you ready to serve and lead to your co-CDMians? File your candidacy, then this our 𝟐𝟎𝟐𝟒 𝐒𝐭𝐮𝐝𝐞𝐧𝐭 𝐂𝐨𝐧𝐠𝐫𝐞𝐬𝐬; 𝐈𝐠𝐧𝐢𝐭𝐞: 𝐄𝐦𝐩𝐨𝐰𝐞𝐫𝐢𝐧𝐠 𝐓𝐨𝐦𝐨𝐫𝐫𝐨𝐰\'𝐬 𝐋𝐞𝐚𝐝𝐞𝐫𝐬. File your candidacy for positions of the next set of Colegio de Montalban Student Leaders who\'s going to be the voice of CDMians. ', 'uploads\\441548113_313781575100487_3750641017732309778_n.jpg', '2024-05-19 04:34:54'),
(21, 1, 0, 'As we approach the end of the semester, take note of the following important dates for May:', 'uploads\\444168751_324206214104429_8266939669972569500_n.jpg', '2024-05-19 04:36:16'),
(22, 1, 0, 'Great news, CdMians!Guess what? We\'re rolling out something special just for you! Calling all currently enrolled non-graduating students: You can now REQUEST your very own institutional emails! Don\'t miss out on getting your very own [username]@student.pnm.edu.ph address!', 'uploads\\425504924_318510424674008_7651710184984268185_n.jpg', '2024-05-19 04:37:50'),
(40, 2, 0, 'In observance of Labor Day, as declared in Proclamation No. 368 by the Office of the President, please be informed that May 1, 2024, will be a regular holiday. Consequently, there will be no classes, and offices will be closed on this day.\r\nKindly take note that classes and office operations will resume on May 2, 2024, Thursday.\r\n', 'uploads\\441028759_309761835548867_2964152354472671495_n.jpg', '2024-05-21 10:50:06');

-- --------------------------------------------------------

--
-- Table structure for table `manage_request`
--

CREATE TABLE `manage_request` (
  `request_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `request` varchar(250) NOT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `manage_request`
--

INSERT INTO `manage_request` (`request_id`, `admin_id`, `user_id`, `request`, `status`) VALUES
(2, 0, 2, 'get me approved', 'denied'),
(9, 0, 36, 'lah', 'approved'),
(15, 0, 1, 'onegai shimasu', 'posted');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `report_content` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`report_id`, `user_id`, `username`, `report_content`) VALUES
(1, 1, 'RinYuRin', 'its good ');

-- --------------------------------------------------------

--
-- Table structure for table `user_credentials`
--

CREATE TABLE `user_credentials` (
  `user_id` int(11) NOT NULL,
  `student_id` varchar(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_credentials`
--

INSERT INTO `user_credentials` (`user_id`, `student_id`, `username`, `email`, `password`) VALUES
(1, '22-01862', 'RinYuRin', 'aldrinocampo102903@gmail.com', 'azraelking'),
(2, '22-01863', 'aldwin96', 'aldwinocampo0620@gmail.com', '12345'),
(36, '22-01864', 'FateAzrael', 'azraelking1029@gmail.com', 'azraelking'),
(37, '22-01865', 'Yukirin', 'orakawayukirin102903@gmail.com', 'yukirin1029'),
(38, '22-01867', 'carmilla', 'undeadqueen@gmail.com', 'a12345678'),
(39, '22-01868', 'cecilion', 'undeadking@gmail.com', 'infinityeigth');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_credentials`
--
ALTER TABLE `admin_credentials`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `calendar_event`
--
ALTER TABLE `calendar_event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `login_history`
--
ALTER TABLE `login_history`
  ADD PRIMARY KEY (`login_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `manage_comments`
--
ALTER TABLE `manage_comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `manage_post`
--
ALTER TABLE `manage_post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `manage_request`
--
ALTER TABLE `manage_request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `user_credentials`
--
ALTER TABLE `user_credentials`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `unique_id` (`student_id`),
  ADD KEY `student_id` (`student_id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_credentials`
--
ALTER TABLE `admin_credentials`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `calendar_event`
--
ALTER TABLE `calendar_event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `login_history`
--
ALTER TABLE `login_history`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `manage_comments`
--
ALTER TABLE `manage_comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `manage_post`
--
ALTER TABLE `manage_post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `manage_request`
--
ALTER TABLE `manage_request`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_credentials`
--
ALTER TABLE `user_credentials`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `login_history`
--
ALTER TABLE `login_history`
  ADD CONSTRAINT `login_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_credentials` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
