﻿Public Class Form1
    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs)

    End Sub
End Class
