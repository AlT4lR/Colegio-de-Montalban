﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Button

Public Class Form8
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked Then
            TextBox1.Text = "RadioButton 1 is Clicked"

        Else
            TextBox1.Clear()

        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked Then
            TextBox2.Text = "RadioButton 2 is Clicked"

        Else
            TextBox2.Clear()

        End If
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked Then
            TextBox3.Text = "RadioButton 2 is Clicked"

        Else
            TextBox3.Clear()

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim form1 As New Form1()

        form1.Show()
        Me.Hide()
    End Sub
End Class