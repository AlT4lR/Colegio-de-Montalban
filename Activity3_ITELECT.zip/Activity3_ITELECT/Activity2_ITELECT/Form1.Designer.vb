﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LoginPanel = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.logintextbox2 = New System.Windows.Forms.TextBox()
        Me.logintextbox1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PasswordRecovPanel = New System.Windows.Forms.Panel()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.RegistrationPanel = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.regtextbox2 = New System.Windows.Forms.TextBox()
        Me.regtextbox1 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LoginPanel.SuspendLayout()
        Me.PasswordRecovPanel.SuspendLayout()
        Me.RegistrationPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'LoginPanel
        '
        Me.LoginPanel.Controls.Add(Me.Button3)
        Me.LoginPanel.Controls.Add(Me.Label5)
        Me.LoginPanel.Controls.Add(Me.Button2)
        Me.LoginPanel.Controls.Add(Me.Label4)
        Me.LoginPanel.Controls.Add(Me.Button1)
        Me.LoginPanel.Controls.Add(Me.Label3)
        Me.LoginPanel.Controls.Add(Me.logintextbox2)
        Me.LoginPanel.Controls.Add(Me.logintextbox1)
        Me.LoginPanel.Controls.Add(Me.Label2)
        Me.LoginPanel.Controls.Add(Me.Label1)
        Me.LoginPanel.Location = New System.Drawing.Point(12, 9)
        Me.LoginPanel.Name = "LoginPanel"
        Me.LoginPanel.Size = New System.Drawing.Size(642, 523)
        Me.LoginPanel.TabIndex = 0
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(250, 382)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(103, 32)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = "Recover"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(101, 388)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(130, 29)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Forgot Password"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(271, 257)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(103, 32)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Click Me!"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(192, 263)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 29)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Register"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(206, 312)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(156, 61)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Enter"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Bauhaus 93", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(217, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 45)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Login"
        '
        'logintextbox2
        '
        Me.logintextbox2.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logintextbox2.Location = New System.Drawing.Point(190, 211)
        Me.logintextbox2.Name = "logintextbox2"
        Me.logintextbox2.Size = New System.Drawing.Size(198, 37)
        Me.logintextbox2.TabIndex = 3
        '
        'logintextbox1
        '
        Me.logintextbox1.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logintextbox1.Location = New System.Drawing.Point(190, 162)
        Me.logintextbox1.Name = "logintextbox1"
        Me.logintextbox1.Size = New System.Drawing.Size(198, 37)
        Me.logintextbox1.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(101, 211)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 29)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Password:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(101, 165)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 29)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Username:"
        '
        'PasswordRecovPanel
        '
        Me.PasswordRecovPanel.Controls.Add(Me.Button5)
        Me.PasswordRecovPanel.Controls.Add(Me.Label11)
        Me.PasswordRecovPanel.Controls.Add(Me.Label13)
        Me.PasswordRecovPanel.Location = New System.Drawing.Point(12, 12)
        Me.PasswordRecovPanel.Name = "PasswordRecovPanel"
        Me.PasswordRecovPanel.Size = New System.Drawing.Size(614, 523)
        Me.PasswordRecovPanel.TabIndex = 8
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(194, 261)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(137, 44)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = "Password"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(198, 223)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(136, 29)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Are you Acoustic?"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Bauhaus 93", 20.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(98, 151)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(356, 45)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Password Recovery"
        '
        'RegistrationPanel
        '
        Me.RegistrationPanel.Controls.Add(Me.Button4)
        Me.RegistrationPanel.Controls.Add(Me.regtextbox2)
        Me.RegistrationPanel.Controls.Add(Me.regtextbox1)
        Me.RegistrationPanel.Controls.Add(Me.Label8)
        Me.RegistrationPanel.Controls.Add(Me.Label7)
        Me.RegistrationPanel.Controls.Add(Me.Label6)
        Me.RegistrationPanel.Location = New System.Drawing.Point(21, 25)
        Me.RegistrationPanel.Name = "RegistrationPanel"
        Me.RegistrationPanel.Size = New System.Drawing.Size(507, 526)
        Me.RegistrationPanel.TabIndex = 10
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(192, 323)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(137, 44)
        Me.Button4.TabIndex = 7
        Me.Button4.Text = "Register"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'regtextbox2
        '
        Me.regtextbox2.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.regtextbox2.Location = New System.Drawing.Point(173, 209)
        Me.regtextbox2.Name = "regtextbox2"
        Me.regtextbox2.Size = New System.Drawing.Size(204, 37)
        Me.regtextbox2.TabIndex = 5
        '
        'regtextbox1
        '
        Me.regtextbox1.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.regtextbox1.Location = New System.Drawing.Point(173, 163)
        Me.regtextbox1.Name = "regtextbox1"
        Me.regtextbox1.Size = New System.Drawing.Size(204, 37)
        Me.regtextbox1.TabIndex = 4
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(78, 215)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(83, 29)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Password:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Myanmar Text", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(78, 169)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(87, 29)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Username:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Bauhaus 93", 20.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(152, 93)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(235, 45)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Registration"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(561, 685)
        Me.Controls.Add(Me.LoginPanel)
        Me.Controls.Add(Me.PasswordRecovPanel)
        Me.Controls.Add(Me.RegistrationPanel)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.LoginPanel.ResumeLayout(False)
        Me.LoginPanel.PerformLayout()
        Me.PasswordRecovPanel.ResumeLayout(False)
        Me.PasswordRecovPanel.PerformLayout()
        Me.RegistrationPanel.ResumeLayout(False)
        Me.RegistrationPanel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents LoginPanel As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents logintextbox2 As TextBox
    Friend WithEvents logintextbox1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents RegistrationPanel As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents regtextbox2 As TextBox
    Friend WithEvents regtextbox1 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents PasswordRecovPanel As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label11 As Label
End Class
