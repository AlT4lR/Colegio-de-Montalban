﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form1
    Dim registeredUser As String = "Adrian" ' Variable to store registered username
    Dim registeredPass As String = "Vine" ' Variable to store registered password

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoginPanel.Visible = True
        RegistrationPanel.Visible = False
        PasswordRecovPanel.Visible = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim user As String = logintextbox1.Text
        Dim pass As String = logintextbox2.Text

        If user = registeredUser AndAlso pass = registeredPass Then
            MessageBox.Show("Logged in Successfully")
        ElseIf user = registeredUser AndAlso pass = "" Then
            MessageBox.Show("Please Enter your Password")
        ElseIf user = "" AndAlso pass = registeredPass Then
            MessageBox.Show("Please Enter Your Username!")
        ElseIf user = "" AndAlso pass = "" Then
            MessageBox.Show("Please Enter your Username and Password")
        Else
            MessageBox.Show("Wrong Username and Password")
            LoginPanel.Visible = True
            RegistrationPanel.Visible = False
            PasswordRecovPanel.Visible = False
        End If


    End Sub

    ' Registration button
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim newUser As String = regtextbox1.Text
        Dim newPass As String = regtextbox2.Text

        If newUser = "" OrElse newPass = "" Then
            MessageBox.Show("Please enter both username and password for registration.")
        Else
            registeredUser = newUser
            registeredPass = newPass
            MessageBox.Show("Registration successful!")
            LoginPanel.Visible = True
            RegistrationPanel.Visible = False
            PasswordRecovPanel.Visible = False
        End If
    End Sub

    ' Password recovery
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        MessageBox.Show($"Your password is: {registeredPass}")
        LoginPanel.Visible = True
        RegistrationPanel.Visible = False
        PasswordRecovPanel.Visible = False
    End Sub

    ' Show password recovery panel
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        LoginPanel.Visible = False
        RegistrationPanel.Visible = False
        PasswordRecovPanel.Visible = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        RegistrationPanel.Visible = True
        LoginPanel.Visible = False
        PasswordRecovPanel.Visible = False
    End Sub

    Private Sub PasswordRecovPanel_Paint(sender As Object, e As PaintEventArgs)

    End Sub

End Class
