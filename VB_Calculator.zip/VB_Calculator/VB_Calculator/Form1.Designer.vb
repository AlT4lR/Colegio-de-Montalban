﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Screen = New RichTextBox()
        Clear = New Button()
        Divide = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        Button5 = New Button()
        Button6 = New Button()
        Button7 = New Button()
        Button8 = New Button()
        Button9 = New Button()
        Button10 = New Button()
        Button11 = New Button()
        Button12 = New Button()
        Button13 = New Button()
        Button14 = New Button()
        Button16 = New Button()
        ListBox1 = New ListBox()
        SuspendLayout()
        ' 
        ' Screen
        ' 
        Screen.Location = New Point(12, 50)
        Screen.Name = "Screen"
        Screen.RightToLeft = RightToLeft.Yes
        Screen.Size = New Size(368, 99)
        Screen.TabIndex = 0
        Screen.Text = ""
        ' 
        ' Clear
        ' 
        Clear.Location = New Point(14, 163)
        Clear.Name = "Clear"
        Clear.Size = New Size(87, 55)
        Clear.TabIndex = 1
        Clear.Text = "AC"
        Clear.UseVisualStyleBackColor = True
        ' 
        ' Divide
        ' 
        Divide.Location = New Point(293, 161)
        Divide.Name = "Divide"
        Divide.Size = New Size(87, 57)
        Divide.TabIndex = 3
        Divide.Text = "/"
        Divide.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(293, 224)
        Button2.Name = "Button2"
        Button2.Size = New Size(87, 57)
        Button2.TabIndex = 4
        Button2.Text = "*"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(293, 287)
        Button3.Name = "Button3"
        Button3.Size = New Size(87, 57)
        Button3.TabIndex = 5
        Button3.Text = "-"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(293, 350)
        Button4.Name = "Button4"
        Button4.Size = New Size(87, 57)
        Button4.TabIndex = 6
        Button4.Text = "+"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Location = New Point(293, 413)
        Button5.Name = "Button5"
        Button5.Size = New Size(87, 57)
        Button5.TabIndex = 7
        Button5.Text = "="
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Location = New Point(14, 224)
        Button6.Name = "Button6"
        Button6.Size = New Size(87, 57)
        Button6.TabIndex = 8
        Button6.Text = "7"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.Location = New Point(107, 224)
        Button7.Name = "Button7"
        Button7.Size = New Size(87, 57)
        Button7.TabIndex = 9
        Button7.Text = "8"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button8
        ' 
        Button8.Location = New Point(200, 224)
        Button8.MaximumSize = New Size(87, 57)
        Button8.MinimumSize = New Size(87, 57)
        Button8.Name = "Button8"
        Button8.Size = New Size(87, 57)
        Button8.TabIndex = 10
        Button8.Text = "9"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Button9
        ' 
        Button9.Location = New Point(14, 287)
        Button9.Name = "Button9"
        Button9.Size = New Size(87, 57)
        Button9.TabIndex = 11
        Button9.Text = "4"
        Button9.UseVisualStyleBackColor = True
        ' 
        ' Button10
        ' 
        Button10.Location = New Point(107, 287)
        Button10.Name = "Button10"
        Button10.Size = New Size(87, 57)
        Button10.TabIndex = 12
        Button10.Text = "5"
        Button10.UseVisualStyleBackColor = True
        ' 
        ' Button11
        ' 
        Button11.Location = New Point(200, 287)
        Button11.Name = "Button11"
        Button11.Size = New Size(87, 57)
        Button11.TabIndex = 13
        Button11.Text = "6"
        Button11.UseVisualStyleBackColor = True
        ' 
        ' Button12
        ' 
        Button12.Location = New Point(14, 350)
        Button12.Name = "Button12"
        Button12.Size = New Size(87, 57)
        Button12.TabIndex = 14
        Button12.Text = "1"
        Button12.UseVisualStyleBackColor = True
        ' 
        ' Button13
        ' 
        Button13.Location = New Point(107, 350)
        Button13.Name = "Button13"
        Button13.Size = New Size(87, 57)
        Button13.TabIndex = 15
        Button13.Text = "2"
        Button13.UseVisualStyleBackColor = True
        ' 
        ' Button14
        ' 
        Button14.Location = New Point(200, 350)
        Button14.Name = "Button14"
        Button14.Size = New Size(87, 57)
        Button14.TabIndex = 16
        Button14.Text = "3"
        Button14.UseVisualStyleBackColor = True
        ' 
        ' Button16
        ' 
        Button16.Location = New Point(107, 413)
        Button16.Name = "Button16"
        Button16.Size = New Size(87, 57)
        Button16.TabIndex = 18
        Button16.Text = "0"
        Button16.UseVisualStyleBackColor = True
        ' 
        ' ListBox1
        ' 
        ListBox1.FormattingEnabled = True
        ListBox1.ItemHeight = 25
        ListBox1.Location = New Point(200, 15)
        ListBox1.Name = "ListBox1"
        ListBox1.Size = New Size(180, 29)
        ListBox1.TabIndex = 20
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(399, 489)
        Controls.Add(ListBox1)
        Controls.Add(Button16)
        Controls.Add(Button14)
        Controls.Add(Button13)
        Controls.Add(Button12)
        Controls.Add(Button11)
        Controls.Add(Button10)
        Controls.Add(Button9)
        Controls.Add(Button8)
        Controls.Add(Button7)
        Controls.Add(Button6)
        Controls.Add(Button5)
        Controls.Add(Button4)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Divide)
        Controls.Add(Clear)
        Controls.Add(Screen)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
    End Sub

    Friend WithEvents Screen As RichTextBox
    Friend WithEvents Clear As Button
    Friend WithEvents Divide As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents ListBox1 As ListBox

End Class
