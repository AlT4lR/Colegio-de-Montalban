﻿'Cruz Adrian Vine A.
Imports System.Runtime.InteropServices.JavaScript.JSType
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form1
    ' Variables to store numbers and operations
    Private Cnum1 As Double
    Private Cnum2 As Double
    Private operation As Char
    Private clearInput As Boolean = True

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        operation = "+"
        Cnum1 = Val(Screen.Text)
        Screen.Clear()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        operation = "-"
        Cnum1 = Val(Screen.Text)
        Screen.Clear()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        operation = "*"
        Cnum1 = Val(Screen.Text)
        Screen.Clear()
    End Sub

    Private Sub Divide_Click(sender As Object, e As EventArgs) Handles Divide.Click
        operation = "/"
        Cnum1 = Val(Screen.Text)
        Screen.Clear()
    End Sub

    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles Clear.Click
        Screen.Clear()
        clearInput = True
    End Sub

    Private Sub NumberButtonClick(number As String)
        If clearInput Then
            Screen.Clear()
            clearInput = False
        End If
        Screen.Text &= number
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        NumberButtonClick("1")
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        NumberButtonClick("2")
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        NumberButtonClick("3")
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        NumberButtonClick("4")
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        NumberButtonClick("5")
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        NumberButtonClick("6")
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        NumberButtonClick("7")
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        NumberButtonClick("8")
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        NumberButtonClick("9")
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        NumberButtonClick("0")
    End Sub

    Private Sub UpdateHistory(calculation As String)
        ListBox1.Items.Add(calculation)
    End Sub
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If clearInput Then Exit Sub

        Cnum2 = Val(Screen.Text)
        Dim result As Double

        Select Case operation
            Case "+"
                result = Cnum1 + Cnum2
            Case "-"
                result = Cnum1 - Cnum2
            Case "*"
                result = Cnum1 * Cnum2
            Case "/"
                If Cnum2 = 0 Then
                    MessageBox.Show("Cannot divide by zero!")
                End If
                result = Cnum1 / Cnum2
        End Select

        Screen.Text = result.ToString()
        clearInput = True
        UpdateHistory($"{Cnum1} {operation} {Cnum2} = {result}")
    End Sub

    Private Sub Screen_TextChanged(sender As Object, e As EventArgs) Handles Screen.TextChanged

    End Sub
End Class
